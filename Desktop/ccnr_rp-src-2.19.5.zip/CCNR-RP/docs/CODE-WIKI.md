# CCNR-RP 模组 Code Wiki（完整版）

> 本文档基于仓库 `HEAD`（版本 `2.19.5`，Forge 1.20.1 / Mojang 官方映射）源码静态分析生成，
> 覆盖：项目整体架构、主要模块职责、关键类与函数、依赖关系和项目运行方式。
> 与既有 [code-wiki.md](code-wiki.md)（v2.19.0 基线）互补，本文档以当前源码为准。

---

## 目录

1. [项目概述](#1-项目概述)
2. [技术栈](#2-技术栈)
3. [目录结构](#3-目录结构)
4. [架构总览](#4-架构总览)
5. [核心模块详解](#5-核心模块详解)
   - [5.1 模组入口 CCNRRPMod](#51-模组入口-ccnrrpmod)
   - [5.2 配置系统 config](#52-配置系统-config)
   - [5.3 数据结构化存储 data（数据库后端 + 配置加载）](#53-数据结构化存储-data数据库后端--配置加载)
   - [5.4 阵营系统 faction](#54-阵营系统-faction)
   - [5.5 职业与装备 profession](#55-职业与装备-profession)
   - [5.6 用户系统 user](#56-用户系统-user)
   - [5.7 角色服务 character](#57-角色服务-character)
   - [5.8 状态管理 status](#58-状态管理-status)
   - [5.9 经验系统 experience](#59-经验系统-experience)
   - [5.10 事件系统 event](#510-事件系统-event)
   - [5.11 刷新框架 spawn](#511-刷新框架-spawn)
   - [5.12 动画引擎 animation](#512-动画引擎-animation)
   - [5.13 序列引擎 sequence](#513-序列引擎-sequence)
   - [5.14 素材库 assets / 音乐 music](#514-素材库-assets--音乐-music)
   - [5.15 网络层 network](#515-网络层-network)
   - [5.16 命令系统 command](#516-命令系统-command)
   - [5.17 客户端 client](#517-客户端-client)
   - [5.18 实用工具 util / GUI 工厂 / 可选联动](#518-实用工具-util--gui-工厂--可选联动)
6. [依赖关系](#6-依赖关系)
7. [数据存储与配置分层](#7-数据存储与配置分层)
8. [运行方式](#8-运行方式)
9. [测试体系](#9-测试体系)
10. [设计与工程约定](#10-设计与工程约定)

---

## 1. 项目概述

CCNR-RP 是一个基于 **Forge 47.2.0+（Minecraft 1.20.1）** 的服务端权威 RolePlay 模组，
围绕"量子科学设施（CCNR 机构）"世界观构建。它提供八/九大系统并形成完整闭环：

**事件 → 刷新波/招募 → 部署 → 判死 → 冷却 → 复活 → 经验结算**

| 系统 | 说明 |
| --- | --- |
| P1 阵营关系 | 敌对/中立/友好 + 阵营组批量声明 |
| P2 人物刷新配置 | 职业/装备 Loadout（含完整 NBT base64 序列化） |
| P3 角色管理 | 用户档案 + 游戏内角色管理终端（K 键） |
| P4 状态 + 遗体 | 状态机、掉线判死、死亡冷却、Corpse 可选联动 |
| P5 经验系统 v3 | 事件广播 + 规则引擎 + 表达式求值 + 结算 |
| P6 事件系统 | 阶段时间线 + 触发器求值 + 事件生命周期 |
| P7 动画系统 | 数据驱动序列动画，五种公共钩子 |
| P8 刷新框架 | 自刷新 + 复活波 + 招募兜底 + 首次入服自动部署 |
| 数据库后端 | SQLite/MySQL 双后端，JDBC 微 ORM，多配置档热切换 |

**核心特色**：服务端权威（客户端只发意图）、规则逻辑无 MC import 的纯类设计、JSON 原子写、
服务器素材中央下发（按哈希增量下载）、开发环境零第三方强制运行时依赖。

---

## 2. 技术栈

| 项 | 值 |
| --- | --- |
| 游戏 | Minecraft 1.20.1（范围 `[1.20.1,1.21)`） |
| 加载器 | Forge `47.2.0`（范围 `[47,)`），javafml |
| 映射 | official（Mojang 官方映射 1.20.1） |
| 构建 JDK | JDK 21（`java.toolchain`），`--release 17` 产出 Java 17 字节码 |
| 构建工具 | Gradle（ForgeGradle `[6.0,6.2)`、MixinGradle 0.7.38、Spotless 6.25.0） |
| 序列化 | Gson（JSON）+ JDBC（数据库） |
| 数据库驱动 | `sqlite-jdbc 3.45.3.0`（jarJar 打包）、`mysql-connector-j 8.3.0` |
| 测试 | JUnit 5（JUnit BOM 5.11.4），`-PrunTests` 门控 |
| 代码风格 | spotless palantirJavaFormat + license 头 + `compileJava -Xlint:all` |
| CI | GitHub Actions（ubuntu-latest + temurin JDK21） |
| 可选依赖 | Corpse（`corpse` modid，`mandatory=false`）；LDLib（`ldlib`，仅客户端界面，`mandatory=false`） |

---

## 3. 目录结构

```
CCNR-RP/
├── .github/workflows/build.yml      # CI：构建 + spotlessCheck + 单测 + 上传产物 → Release
├── config/spotless/license-header.txt
├── docs/                            # 设计文档（00 总览 ~ 12 数据库设计）与既有 code-wiki.md
├── gradle/wrapper/                  # Gradle Wrapper
├── scripts/
│   ├── fetch-corpse.sh              # 下载 Corpse 编译期依赖 → libs/
│   └── convert-music-to-ogg.sh      # 音乐转 ogg 工具
├── src/main/java/com/ccnrcom/rp/    # 模组主代码（按系统分包）
├── src/main/resources/
│   ├── META-INF/mods.toml
│   ├── ccnr_rp.mixins.json          # Mixin 配置（InventoryObserverMixin）
│   ├── pack.mcmeta
│   └── assets/ccnr_rp/
│       ├── defaults/                # factions/events/animations/phases/spawn_waves 默认 JSON
│       ├── lang/                    # en_us / zh_cn
│       └── shaders/core/            # rendertype_round_rect 圆角矩形着色器
├── src/test/java/com/ccnrcom/rp/    # JUnit5 单元测试（纯逻辑层）
├── build.gradle / settings.gradle / gradle.properties
├── AGENTS.md / README.md / CHANGELOG.md
└── LICENSE (MIT)
```

---

## 4. 架构总览

### 4.1 分层模型

```
                    ┌─────────────────────────────────────────────┐
  客户端 (Dist.CLIENT)│  client.* 界面/HUD/预览/音画/缓存/包处理      │
   ───────────────── │  cmdcam.CamSceneBridge（CMDCam 联动）         │
  网络层              │  network.RpChannels + RpPackets（~48 种包）   │
   ──────────────────────────────────────────────────────────────
  服务端 (权威)       │  command.*（/rp 命令树）                       │
                    │  各系统 Manager/Service（Event/Spawn/Status…）  │
                    │  纯逻辑类（FactionGraph/StatusMachine/LevelCurve│
                    │  /TriggerEvaluator/SpawnModels/WaveSelector…）  │
                    └─────────────────────────────────────────────
  数据层             │  data.*（ConfigStore/ConfigReloader/Database / │
                    │  orm 微 ORM）+ util.JsonUtil（原子写）           │
                    └─────────────────────────────────────────────
  持久化             │  disk: config/ccnr_rp/*.json, world/ccnr_rp/    │
                    │  db: SQLite / MySQL（可选启用）                  │
                    └─────────────────────────────────────────────
```

设计准则：
- **规则逻辑纯类化**：`FactionGraph`、`StatusMachine`、`LevelCurve`、`TriggerEvaluator`、`ExprParser/ExprEvaluator`、
  `SpawnModels`、`AnimationModels`、`ProfessionJson` 等均为**无 MC import 的纯类**，可直接 JUnit 测试。
- **MC 类型收敛为薄适配层**：`LoadoutManager`/`ItemStackCodec`（ItemStack ↔ JSON）、`Database`（JDBC）、
  `AnimationEngine`（服务端决策+发包）、`ClientAnimationPlayer`（客户端执行）。
- **服务端权威**：所有状态变更（部署/判死/招募/结算）由服务端校验并落地，客户端仅发送意图（C2S 包）。

### 4.2 生命周期总览（CCNRRPMod 装配顺序）

1. **构造**（`CCNRRPMod()`）：注册 serverconfig `CCNRRPConfig.SPEC` → `commonSetup` → `RpChannels.register()`
   （注册全部 48 种消息）→ `RpUIFactory.register()` → 注册自身与 `Permissions` 到 Forge 事件总线。
2. **ServerAboutToStart**：`Database.connect()`（读 `config/db.properties`，未启用则无副作用）
   → `CCNRRPConfig.applyDbOverrides()`（数据库覆盖调参）→ `ManagerSettings` → `AssetLibrary.ensureDefaults()`
   → `FactionManager.load()` → `CharacterService` → `UserService` → `StatusManager`（注册总线）
   → `CorpseBridge.registerHooks()` → `ExperienceService`（注册总线）→ `SpawnFramework`（注册总线）
   → `AnimationEngine` → `EventManager`（注册总线）→ `SequenceEngine`（注册总线）。
3. **PlayerLoggedIn**：首次入服部署入队（`SpawnFramework.maybeQueueFirstJoin`）→ 冷却结束回观察者归一化
   → 发送角色列表 + 头顶标签广播 + 素材清单下发（`AssetLibrary.sendManifest`）→ 死亡冷却中强制旁观者
   → 补发离线结算通知 + 经验规则集。
4. **PlayerLoggedOut**：清理素材待同步标记 → 取消招募邀请 → 头顶标签刷新。
5. **ServerStopping**（对称清理）：`Database.disconnect()` → `CharacterService.shutdownBroadcaster()`
   → `users.save()` → 注销各总线监听 → `CorpseBridge.clearCaptured()` → `SequenceEngine.clearConscripts()`
   → 全部静态服务引用置 null。

### 4.3 核心业务闭环

```
event 触发 ──► spawnFramework 刷新波/征召（RecruitManager 邀请制）
                  │ 玩家接受
                  ▼
         部署链路：校验（状态/冷却/limits）→ LoadoutManager.apply → 传送到 deployAt
                  │                                    │
                正式用户状态 ALIVE ◄──── 临时征召兵（不进角色库）
                  │
            死亡/掉线判死（StatusManager）
                  │ 生成遗体（CorpseBridge）/ 冷却
                  ▼
         复活波 / 招募 / 自部署（冷却结束）
                  ▼
         ExperienceService：事件广播(character_alive/kill/death) → 规则引擎 → 待结算列表 → /rp settle 结算
```

---

## 5. 核心模块详解

### 5.1 模组入口-CCNRRPMod

**文件**：[CCNRRPMod.java](/workspace/CCNR-RP/src/main/java/com/ccnrcom/rp/CCNRRPMod.java)

**职责**：装配/生命周期中心。持有全部服务静态引用（`factions` / `managerSettings` / `sequenceEngine` /
`characters` / `users` / `statusManager` / `experience` / `eventManager` / `spawnFramework` /
`animationEngine` / `database`）。

| 关键成员 | 类型 | 说明 |
| --- | --- | --- |
| `MODID` | `String="ccnr_rp"` | 模组 id |
| `onRegisterCommands` | 事件 | 注册 `/rp` 命令树 |
| `onServerAboutToStart` | 事件 | 创建并装配全部运行时服务（见 4.2） |
| `onPlayerLoggedIn/Out` | 事件 | 登录/登出归一化与清理 |
| `onServerStopping` | 事件 | 对称清理、落盘、注销 |

### 5.2 配置系统-config

**文件**：[CCNRRPConfig.java](/workspace/CCNR-RP/src/main/java/com/ccnrcom/rp/config/CCNRRPConfig.java)、
[ManagerSettings.java](/workspace/CCNR-RP/src/main/java/com/ccnrcom/rp/config/ManagerSettings.java)

**分层**：
- **serverconfig toml（调参）**：`serverconfig/ccnr_rp-server.toml`，Forge `ForgeConfigSpec`。
  关键项：`DEATH_COOLDOWN_MINUTES`（死亡冷却，默认 30 分钟）、`OFFLINE_GRACE_SECONDS`（掉线判死宽限 10s）、
  `OFFLINE_POLL_SECONDS`（兜底轮询 5s）、`EVENT_EVAL_INTERVAL_TICKS`（事件求值 20t）、
  `SPAWN_POLL_TICKS` / `SPAWN_DELAY_TICKS`（刷新轮询/部署延迟）、`LEVEL_BASE/LEVEL_POW`（等级曲线 100/2.0）、
  `NAMETAG_*`（头顶标签开关/徽章大小/高度）、`KILL_FRIENDLY_NOTICE`（误杀提示开关+偏移）。
- **ManagerSettings（入服规则）**：`settings.json` 管理端可编辑项（如 `forceRetain` 强制保留、`openPanelOnJoin` 自动开面板）。

**关键方法**：
- `CCNRRPConfig.applyDbOverrides()`：数据库启用时，用当前配置档 `server_settings` 覆盖各 `ConfigValue` 运行时值。

### 5.3 数据结构化存储-data（数据库后端 + 配置加载）

**文件**：`Database` / `DbConfig` / `DbSchema` / `RuntimeMigrator` / `SqlDialect` / `DbType` /
`ConfigStore` / `ConfigReloader` / `ServerSettingsStore` / `AssetRepository` / `UserRepository` /
`orm/`（`@Table` `@Column` `@Id` `@JsonColumn` `@Blob` `SqlMapper`）。

#### Database（JDBC 门面）

- `connect()`：读取 `config/db.properties`（`db.enabled` / `db.type=sqlite|mysql`），建连 + `DbSchema.bootstrap()` 建表 + `RuntimeMigrator` 迁移；失败则保持未连接。
- 单一 `Connection` + `ReentrantLock` 串行化访问；**写走专用单线程 daemon executor**（`ccnr-rp-db-writer`），读走主线程。
- `syncRead` / `syncWrite` 回调式 API；`enabled()` 为 false 时全部方法空操作（文件行为不变）。

#### orm 微 ORM（SqlMapper）

- 仅支持 **record** 实体；注解驱动映射到表列；`JsonColumn`→Gson TEXT、`Blob`→byte[]；
- 按 record 组件顺序经 canonical 构造器重建实例；`Id` 注解支持复合主键。

#### DbSchema（DDL）

统一跨库类型 `TEXT/INTEGER/BLOB`（布尔存 0/1），`CREATE TABLE IF NOT EXISTS` 幂等；
表：`schema_version`、`meta`、`config_profiles`（多配置档）、`config_documents`、`users`、
`user_pending_xp`、`pending_notices`、`team_waves_done`、`server_settings`、`assets` 等，并由 `runtime_migrations` 表跟踪迁移。

#### ConfigStore（配置读写统一入口）

- `load(name)` / `save(name, json)`：**DB 启用时读写库 `config_documents`（按当前 profile 过滤），否则读写磁盘** `config/ccnr_rp/`。
- 配 `util/JsonUtil` 实现 JSON 原子写（临时文件 + rename，损坏保留 `.bak`）。

### 5.4 阵营系统-faction

**文件**：`FactionModels` / `FactionGraph` / `FactionManager` / `FactionProfessions` / `RelationType`

**模型（FactionModels，纯数据 record）**：
- `Faction(id, tier, name, color, groupIds, icon, anthem, professions…)` — 阵营（带 tier/图标/出场音乐/内置职业）
- `FactionGroup(id, memberIds)` — 阵营组
- `RelationRule(from[], to[], type)` — 关系规则（笛卡尔积展开）
- `RelationType`：`HOSTILE / NEUTRAL / FRIENDLY`
- `ParseResult(graph, errors, warnings)`、`Snapshot`（供关系编辑保存）

**FactionGraph（纯逻辑）**：
- `parse(factionList, groupList, ruleList)`：校验（阵营重复/组成员不存在/命名空间冲突）+ 规则展开；从上到下优先级，先声明者生效，WARN 重复规则。
- `relation(a, b)`：同阵营恒 FRIENDLY；组关系展开；未命中默认 NEUTRAL；双向对称。
- `Snapshot snapshot()`：供 `FactionGraphOpenS2C` 下发给关系图 GUI。

**FactionManager（薄适配层）**：
- `load()`：文件缺失时从 `assets/ccnr_rp/defaults/factions.json` 写默认；解析失败仅日志 + 空图运行。
- `save()` / `reload()`：保存/重载；`graph()` 暴露当前图；`profession(...)` 经 `FactionProfessions` 解析职业归属。

### 5.5 职业与装备-profession

**文件**：`ProfessionJson` / `ItemStackCodec` / `LoadoutManager`

- `ProfessionJson.SlotItem(slot, item, count, nbtBase64)` — 单槽物品（纯数据）。
  `ProfessionJson`：`slotToJson/slotFromJson/listToJson/listFromJson`（纯逻辑校验：缺 `slot/item` 报错带路径）。
- `ItemStackCodec`：`fromStack(slot, stack)` 完整 NBT → `NbtIo` 字节 → base64；`toStack` 反向还原；
  `encodeNbt/decodeNbt` 无注册表依赖，可独立单测。
- `LoadoutManager`：
  - `capture(player, full)`：采集背包（0-35）/护甲（36-39）/副手（40），`--full` 时含全部背包。
  - `apply(player, loadoutJson)`：按槽位发放装备（校验目标存在、非空、清空冲突槽位）。

### 5.6 用户系统-user

**文件**：[UserService.java](/workspace/CCNR-RP/src/main/java/com/ccnrcom/rp/user/UserService.java)

**模型**：`UserProfile(xp, lastCreateAt, anySupportRevive, status, professionId, factionId, cooldownUntil, dutySeconds, pendingXp)`
——一个玩家 UUID = 一个用户，状态/职位/冷却/执勤时长/待结算 XP 全挂用户上。持久化 `world/ccnr_rp/user_profiles.json`（version 3，原子写）。

**关键方法**（均有 DB 可选后端 `UserRepository`）：`load/save/status/cooldownUntil/isAlive/onCooldown/`、
`setStatus/setCooldown/`、`pendingXp/addPendingXp/clearPendingXp/`、`dutySeconds/`、`anySupportRevive`、`lastCreateAt`。
`save()` 已含 `CharacterService.shutdownBroadcaster()` 前缀清理依赖；支持 DB 启用时读写 `users/user_pending_xp` 表。

### 5.7 角色服务-character

**文件**：[CharacterService.java](/workspace/CCNR-RP/src/main/java/com/ccnrcom/rp/character/CharacterService.java)

v2.19 起多角色角色库已移除，**以 UserService 单用户档案为唯一身份**。本类职责变为：
- `sendList(player)`：发送 `CharacterListS2C`（页面全量状态快照：用户档案/阵营/职业/关系/设置/占位）。
- `broadcastPlayerTags()` / `refreshPlayerTags()`：头顶悬浮标签异步广播——后台线程构建 payload（合并去重），回主线程逐人发包。
- `broadcastConfig(...)`：配置变更全服异步广播（后台 `ccnr-rp-config-broadcast` 线程构建纯数据 → 主线程发包）。
- 管理器（阵营/职业/事件/阶段/波）管理员操作入口；音乐上传临时缓存（`musicUploads`）。
- `shutdownBroadcaster()`：静态清理。

### 5.8 状态管理-status

**文件**：`CharacterStatus`（枚举 `OBSERVING/ALIVE/DEAD`）、`StatusMachine`、`StatusManager`、`RetireFlag`

**StatusMachine（纯逻辑）**：
- `transition(from, to)`：合法迁移表——`OBSERVING→ALIVE`（部署）、`ALIVE→DEAD|OBSERVING`、`DEAD→ALIVE`（复活需冷却结束）；同态幂等成功；否则返回拒绝原因（`Optional<String>`）。
- `selfDeployable(status, professionSelfDeploy)`：仅观察且职业允许自部署。
- `waveEligible(status, selfDeploy)`：DEAD 优先；观察者仅接受非自部署类型。

**StatusManager（服务端落地）**：
- **掉线判死两条幂等路径**：`onPlayerLoggedOut` 事件主路径（`forceRetain` 开启时立即判死 `retire(uuid, player, "offline", RetireFlag.SPAWN_CORPSE|OFFLINE)`）+ 定期轮询兜底（alive 且离线超 `OFFLINE_GRACE_SECONDS` 补判死）。
- `retire(...)`：`experience.emitDeath` 结算前赋予 → 状态 `ALIVE→DEAD`，记录死亡地点 `DeathSpot`；在线判死生成遗体（经 CorpseBridge 或原生死亡）。
- 死亡强制旁观者（`GameType.SPECTATOR`），复活后传回尸体旁旁观；关服清除 `deathSpots`。

### 5.9 经验系统-experience

**文件**：`ExperienceService` / `ExperienceEventRegistry` / `ExperienceRule` / `ExprParser` / `ExprEvaluator` /
`ExprException` / `LevelCurve` / `PendingNoticeStore` / `XpChangeList`

**设计（v3 规则引擎）**：
- 事件广播：`character_alive`（每 60s 对每个 ALIVE 用户）、`character_kill`、`character_death`（结算开始前赋予；`emitDeath`）。
- 规则引擎：订阅事件 → 条件表达式（false 跳过）→ 数值表达式 + 标题表达式 → 并入 `XpChangeList`（同规则合并）。
- 结算：`/rp settle` 或死亡/断联退场触发；列表求和（可为负）计入累计 XP 后清空（幂等）；`SettleSummary(gain, newXp, newLevel, changes)`。
- 规则存 `config/ccnr_rp/experience_rules.json`，管理面板热重载；缺失写默认规则（值班 +1/击杀 +50/阵亡 -10）。

**纯逻辑组件**：
- `LevelCurve(base, pow)`：`xpForLevel(n)=base*n^pow`，`level(xp)=floor((xp/base)^(1/pow))`，`canLevelUp(xp, curLevel)`；误配兜底。
- `ExperienceRule`：`validate()` 校验事件存在 + 表达式类型（`Kind.BOOL` 等）。
- `ExprParser`：将表达式字符串解析为 AST `Expr`；`ExprEvaluator` 按 `TriggerContext` 变量表求值（支持 `victimType` 等变量与字符串拼接）。

### 5.10 事件系统-event

**文件**：`EventModels` / `EventManager` / `PhaseClock` / `TriggerEvaluator`

**模型**：
- `GamePhase(id, order, durationMinutes, steps)` — 阶段表（phases.json）；
- `Trigger(Type, params)`：`ON_PHASE_START / ON_PHASE_END / ON_TIME / PERIODIC / CONDITION`；
- `EventDefinition(...)` + `EventState` 枚举：`SCHEDULED → RUNNING → SETTLED`；
- `TriggerContext(...)`：当前阶段/day/tick/存活数/死亡数/scoreboard 等求值变量。

**TriggerEvaluator（纯逻辑）**：`evaluate(trigger, ctx)` 按类型求值；`CONDITION` 支持 `DEAD_COUNT/ALIVE_COUNT/SCOREBOARD` 与 `>=/<=/>/</==` 比较。

**PhaseClock（纯逻辑）**：阶段时钟推进（阶段顺序 + 时长，随阶段变化广播）。

**EventManager**：每 `EVENT_EVAL_INTERVAL_TICKS` 求值触发器 → 触发事件（RUNNING + 横幅广播 `EventStateS2C`）→
结束钩子调用动画（`AnimationHooks`）→ 自动结算（P5）→ 刷新波预留接口；`clearAll()` 重置已结束事件；`reload()` 热重载。

### 5.11 刷新框架-spawn

**文件**：`SpawnModels` / `SpawnFramework` / `RecruitManager` / `DeployFlag` / `DeployLimits`

**模型（SpawnModels，纯逻辑）**：
- `Mode`：自刷新/复活波等触发模式；`Wave`（刷新波定义：目标数/职业/阵营/冷却等）、`Candidate(用户, 分数…)`、
- `WaveQuota(aliveShare, pickTarget, …)`：复活波阳间/阴间配额；`Selection(deploy, recruit)` 选人结果。
- `ConscriptDeployMode`：征召部署模式。

**SpawnFramework**（服务端，实现 `RecruitManager.Listener`）：
- 三条通路：**自刷新**（GUI 部署）、**召唤波**（队伍创建轮询触发，20t）、**招募兜底**（右侧列表 + 超时）。
- `deployPlayer(...)`：校验（`StatusMachine.selfDeployable`/冷却/`DeployLimits` 在职限额）→ `LoadoutManager.apply`
  → 传送 `deployAt` → 用户状态置 ALIVE → 通知动画 `player_spawn`。
- 部署落位电影：`PendingLanding` 暂存（出生点来源 wave+faction+profession），客户端播完 HUD 电影 + CMDCam 场景后发 `DeployLandC2S`；120s 超时兜底传送。
- 首次入服：`maybeQueueFirstJoin`（≥2s 等待素材同步后自动部署）。
- 离服：`RecruitManager.onPlayerDisconnect` 取消其全部邀请。

**RecruitManager**：邀请制——每次触发分配独立 UUID `groupId`；`Offer(id, groupId, waveId, kind, charId, charName, playerUuid, deadlineMs, done)`；
接受/拒绝/超时（tick 驱动）；`Listener` 回调：`onRecruitAccepted` / `onWaveFinish` / `onConscriptFinish` / `onOfferDiscarded`。

### 5.12 动画引擎-animation

**文件**：`AnimationModels` / `AnimationEngine` / `AnimationHooks`

- `AnimationModels`（纯逻辑）：`Sequence` / 步骤解析（TITLE / ACTIONBAR / FADE / CAMERA / PARTICLE / SOUND 等）；`parseAll` 校验未知类型拒载。
- `AnimationEngine`（服务端决策+分发）：
  - `reload()`：加载 `animations.json` + 默认钩子绑定：`player_spawn→spawn_intro`、`player_death→player_death`、
    `game_end→game_end`、`event_start→event_start_alarm`、`level_up→level_up`。
  - `play(sequenceId, target(s))` → 发 `AnimationPlayS2C`；`sequence(id)` / `boundSequence(hook)` 查询。
- `AnimationHooks`：公共钩子常量/接口（生/死/游戏结束/事件开始/升级），供其他系统调用（契约冻结在 docs/08）。

### 5.13 序列引擎-sequence

**文件**：[SequenceEngine.java](/workspace/CCNR-RP/src/main/java/com/ccnrcom/rp/sequence/SequenceEngine.java)

- 顺序执行步骤：`WAIT / WAVE / COMMAND / FORCE_PICK`，支持 `{{变量}}` 注入（event/phase/wave/seq/faction/count…）。
- `FORCE_PICK`：**强制征召（邀请制）** —— 为被选用户创建临时征召兵 `Conscript(id, playerUuid, name, professionId, factionId, pending, deployedAt)`；
  不进角色库（不占上限、不出现在 K 面板），接受后部署，拒绝/超时/阵亡即消失（生成 UID 名 + 编制职业）。
- `clearConscripts()` 静态清理；`removeConscriptFor(uuid)` 离服时删除征召身份。

### 5.14 素材库-assets / 音乐-music

**文件**：`assets/AssetLibrary`、`music/MusicStore`

- **AssetLibrary（服务器中央下发）**：素材 = `config/ccnr_rp/audio/*.ogg` + `config/ccnr_rp/textures/*.png`。
  - `ensureDefaults()`：首次启动写入内嵌默认图标；
  - `sendManifest(player)`：下发 `AssetManifestS2C`（名称+哈希列表）；
  - 客户端缺失/变更 → `AssetRequestC2S` → 服务端 `STREAMER` 后台线程按 32KB 分片 `AssetPartS2C` 下发；
  - `markPending/clearPending`：同步完成确认（`AssetSyncDoneC2S`）前**禁用部署/复活**；60s 超时自动放行。
  - 哈希缓存（size/mtime/hash）避免重复计算。
- **MusicStore（服务端音乐库校验）**：文件名规约 `[A-Za-z0-9_-]{1,48}.ogg`；`validate(bytes)` 校验 OggS 魔数 + 20MB 上限（纯逻辑可单测）。
- 音乐解析优先级：**启动器指定 > 职业 > 阵营**（部署入场电影用）。

### 5.15 网络层-network

**文件**：`RpChannels` / `RpPackets`

- 通道：`ccnr_rp:main`，`SimpleChannel`，`PROTOCOL_VERSION="1"`；协议不匹配自动禁用联动（服务端静默跳过）。
- 发送封装：`sendTo(player,msg)`（检测远端通道存在）/ `sendToServer` / `sendToAll` / `hasChannel(conn)`。
- **48 种包**（C2S：意图；S2C：同步/广播），分组：

| 用途 | 包 |
| --- | --- |
| 角色/档案 | `RequestCharacterListC2S`、`CharacterListS2C`、`UserXpS2C`、`PlayerTagsS2C` |
| 部署/状态 | `DeployPositionC2S`、`KillDeployC2S`、`DeployLandC2S`、`DeployNoticeS2C`、`DeathNoticeS2C`、`KillFriendlyNoticeS2C` |
| 招募 | `RecruitOfferS2C`、`RecruitAnswerC2S`、`RecruitPickCharacterC2S`、`ConscriptStateS2C` |
| 音乐上传 | `MusicUploadPartC2S`、`MusicUploadCommitC2S`、`MusicListS2C` |
| 动画/电影 | `AnimationPlayS2C`、`CinematicS2C`、`CamScenePlayC2S`（CMDCam） |
| 事件 | `EventStateS2C`、`AdminEventTriggerC2S` |
| 素材 | `AssetManifestS2C`、`AssetRequestC2S`、`AssetPartS2C`、`AssetSyncDoneC2S` |
| 管理器 | `ManagerRequestC2S/SetC2S/StateS2C/CrudC2S/ImpactC2S/ImpactS2C`、`ServerConfigSetC2S` |
| 管理员快捷 | `AdminSelfProfessionC2S / AdminProfessionSaveFullC2S / AdminFactionSpawnC2S / AdminProfessionSpawnC2S / AdminTeleportC2S / AdminWaveTriggerC2S` |
| 经验 | `RulesStateS2C`、`RuleEditC2S`、`XpListS2C`、`XpSettleAnimS2C` |
| 阵营关系 | `FactionGraphOpenS2C`、`RelationEditC2S` |
| 通用 | `ErrorS2C`、`UserAnySupportC2S` |

### 5.16 命令系统-command

**文件**：`RpCommand` + 各子命令 `FactionCommand / ProfessionCommand / CharacterCommand / StateCommand /
XpCommand / EventCommand / AnimationCommand / SpawnCommand / DbCommand / GuiCommand` + `RpSuggest`（补全建议）

- `RpCommand.register(dispatcher)`：注册字面量根 `rp` + `help`；挂载全部子命令族。
- `admin(PermissionNode)`：管理命令守卫——OP≥2 或拥有 `ccnrrp.admin.*` 权限节点（`util/Permissions`）。
- `mount(builder)`：运行时可动态加子命令。
- 与 GUI 联动兄弟：`GuiCommand` 提供 /rp gui 打开管理面板等。
- `/rp db`（`DbCommand`）：`status/test/migrate/export/flush/connect/profile`——数据库运维。

### 5.17 客户端-client

**文件**（`ClientSetup` / `ClientForgeEvents` / `ClientPacketHandlers` / `ClientAnimationPlayer` /
`ClientAssetCache` / `ClientAudio` / `ClientCharacterState` / 各 Screen/HUD / `CamSceneClient` /
`CameraEffect` / `PlayerNametagRenderer` 等，共 30+ 类）

| 类 | 职责 |
| --- | --- |
| `ClientSetup` | MOD 总线：按键 `K`（角色面板）、`R`（招募弹窗）、着色器注册（RpRoundRect）、HUD 覆盖层注册（fade/recruit/结算） |
| `ClientForgeEvents` | Forge 总线：ClientTick 驱动动画步进/落位/无线电/素材缓存超时看门狗/招募列表清理/自动开面板；键盘处理 |
| `ClientCharacterState` | 客户端镜像（服务端 S2C 维护）：用户档案、等级曲线、头顶标签、关系图、管理器状态、在职统计、征召身份等 |
| `ClientPacketHandlers` | 全部 S2C 包的处理入口（分发到镜像/播放器/缓存） |
| `ClientAnimationPlayer` | 播放 `AnimationPlayS2C` 序列（TITLE/ACTIONBAR/FADE…），tick 驱动步进 |
| `ClientAssetCache` | 素材下载：对比清单哈希 → 存本地 `config/ccnr_rp/skins-cache/`，请求超时看门狗 |
| `ClientAudio` / `RadioPlayer` | 音乐/无线电（打字机逐句推进）播放 |
| `CharacterManagementScreen` 等 | "CCNR:NET 机密终端"三栏网格：机构徽章（tier 着色）/角色档案/详情（3D 预览 `CharacterPreview` + 战术装备槽 + 皮肤上传） |
| `RecruitOverlayHud` / `RecruitPopupScreen` | 右侧常驻招募列表（悬浮 HUD）+ 交互弹窗（R 键） |
| `StatusHud` / `XpHudOverlay` | 背包内状态栏 + 经验结算动画（逐项吸入 → 数字更新 → 停留 5s） |
| `FadeOverlay` / `CameraEffect` / `CinematicController` | 入场电影：淡入淡出 + 镜头效果 + HUD 电影/CMDCam 场景落位判定 |
| `PlayerNametagRenderer` | 服务器下发的头顶悬浮标签渲染（阵营徽章 + 文字） |
| `RpTheme` / `RpIcons` / `RpButton` / `RpScrollbar` / `RpRoundRect` / `RpRelationTab` / `RpRulesTab` | 自绘 UI 组件与主题（含核心着色器 rendertype_round_rect 圆角矩形） |
| `EventBanner` / `DeployNoticeBanner` / `KillFriendlyNoticeHud` | 横幅/提示 HUD |
| `FactionGraphScreen` | 阵营关系图 GUI（基于 `FactionGraphOpenS2C`） |
| `RpAdminScreen` | 管理面板（调参/设置/规则/CRUD，基于 `ManagerStateS2C`） |
| `Cmdcam` 桥：`CamSceneBridge` | CMDCam 联动（可选）：场景播放/落位判定 |

**Mixin**：`mixin/InventoryObserverMixin`（观察者禁止入包）——唯一 Mixin，注解处理器为 mixin 0.8.5。

### 5.18 实用工具-util / GUI 工厂 / 可选联动

| 文件 | 职责 |
| --- | --- |
| `util/JsonUtil` | JSON 读写：统一格式化、**原子写**（tmp + rename）、损坏保留 `.bak` |
| `util/Permissions` | `ccnrrp.admin.*` 权限节点（默认拒绝，OP 恒可用） |
| `util/ConfigCrud` | `config/ccnr_rp/*.json` 通用 CRUD（事件/阶段/刷新波数组段读写），DB 启用时读写库 |
| `gui/RpUIFactory` | 客户端 UI 布局工厂（三栏网格终端） |
| `gui/screen/*` | 通用 Screen 基类（`RpBaseScreen`）与派生（选择/阵营信息/玩家状态/设置） |
| `cmdcam/CamSceneBridge` | CMDCam 场景名读取（客户端 CMDCamMod 存在时；供管理面板补全） |
| `corpse/CorpseBridge` | Corpse 可选联动桥：`ModList` 探测 `isAvailable()`；死亡身份注入（真实 UUID + 「职位+玩家名」名称）、遗体名字牌；缺失降级原生死亡 |
| `config/ManagerSettings` | settings.json 入服规则 |
| `client/CamSceneClient` | CMDCam 客户端场景播放适配 |

---

## 6. 依赖关系

### 6.1 Gradle 依赖图（build.gradle）

```
minecraft "net.minecraftforge:forge:1.20.1-47.2.0"
│
├── compileOnly curse.maven:corpse-316582:7018272      # Corpse 可选联动（运行时 ModList 探测）
├── implementation curse.maven:ldlib-626676:7412415     # LDLib UI 库（客户端界面）
│     └── compileOnly dev.latvian.mods:rhino-forge:2001.2.3-build.10
├── implementation org.xerial:sqlite-jdbc:3.45.3.0      # SQLite 驱动（jarJar 打入模组 jar）
├── implementation com.mysql:mysql-connector-j:8.3.0     # MySQL 驱动
├── annotationProcessor org.spongepowered:mixin:0.8.5:processor
└── testImplementation org.junit:junit-bom:5.11.4 (platform)
```

### 6.2 运行时模块依赖（mods.toml）

| modId | 强制 | 版本范围 | Side | 说明 |
| --- | --- | --- | --- | --- |
| forge | ✅ | `[47,)` | BOTH | 必装 |
| minecraft | ✅ | `[1.20.1,1.21)` | BOTH | 必装 |
| corpse | ❌ | `[1.0.5,)` | BOTH | 缺失降级原生死亡 |
| ldlib | ❌ | `[1.0.48,)` | CLIENT | 缺失时客户端 UI 降级 |

### 6.3 包间依赖方向（服务端）

```
CCNRRPMod (装配中心)
 ├──> config.CCNRRPConfig / ManagerSettings
 ├──> data.*  (ConfigStore / Database / Repository)
 ├──> faction.FactionManager ⇄ FactionGraph(FactionProfessions)
 ├──> character.CharacterService ⇄ user.UserService
 ├──> status.StatusManager ──> corpse.CorpseBridge, experience.ExperienceService(emit)
 ├──> experience.ExperienceService ──> experience.ExprParser/LevelCurve; network.RpChannels
 ├──> event.EventManager ──> animation.AnimationHooks; experience(结算)
 ├──> spawn.SpawnFramework ──> profession.LoadoutManager, status(迁移), animation(钩子)
 ├──> animation.AnimationEngine ──> assets(音乐源), network
 ├──> sequence.SequenceEngine ──> spawn.RecruitManager(征召), animation
 └──> command.* ──> 上述各服务 + network
```

**回环说明**：体验上 `ExperienceService/SpawnFramework/EventManager` 互相通过 `CCNRRPMod` 静态引用协作
（如 `CCNRRPMod.experience` / `CCNRRPMod.spawnFramework`），保证服务端线程内一致性；未初始化时判空防御。

### 6.4 纯逻辑（零 MC 依赖） ↔ 薄适配层清单

| 纯逻辑（可 JUnit 直测） | 对应适配层 |
| --- | --- |
| `FactionGraph` / `FactionModels.ParseResult` | `FactionManager` |
| `StatusMachine` / `CharacterStatus` / `RetireFlag` | `StatusManager` |
| `LevelCurve` / `ExperienceRule` / `ExprParser/ExprEvaluator` | `ExperienceService` |
| `TriggerEvaluator` / `EventModels` / `PhaseClock` | `EventManager` |
| `SpawnModels`（Wave/Quota/Selection） | `SpawnFramework` / `RecruitManager` |
| `AnimationModels` | `AnimationEngine` / `ClientAnimationPlayer` |
| `ProfessionJson` / `ItemStackCodec`（NBT↔base64 纯编解码） | `LoadoutManager` |
| `MusicStore.validate*` / `AssetLibrary` 命名规约 | 网络下发（AssetStreamer） |

---

## 7. 数据存储与配置分层

### 7.1 存储矩阵

| 层 | 路径/来源 | 内容 | 管理员可编辑 | 写入方式 |
| --- | --- | --- | --- | --- |
| 调参 | `serverconfig/ccnr_rp-server.toml` | 冷却/招募超时/经验权重/曲线/tick 间隔 | ✅ | Forge 配置系统 |
| 定义 | `config/ccnr_rp/factions.json` | 阵营/组/关系/职业/Loadout | ✅ | ConfigStore（DB 或磁盘） |
| 定义 | `config/ccnr_rp/phases.json` / `events.json` / `animations.json` / `spawn_waves.json` / `experience_rules.json` | 各系统定义 | ✅ | ConfigStore |
| 运行时 | `world/ccnr_rp/user_profiles.json` | 用户档案（状态/XP/冷却/待结算） | ❌ | 原子写(JsonUtil) |
| 运行时 | `world/ccnr_rp/pending_notices.json`（PendingNoticeStore） | 离线结算通知 | ❌ | 原子写 |
| 素材 | `config/ccnr_rp/audio/*.ogg`、`textures/*.png` | 服务器素材（音乐/图标） | ✅ | 文件 + 哈希清单 |
| 数据库 | `config/db.properties` | `db.enabled/type/profile…` | ✅ | properties |
| 数据库 | SQLite `ccnr_rp.db` / MySQL | 上述各层的**可选镜像**（users/config_documents/server_settings/assets 等） | ✅ | JDBC（写线程） |

### 7.2 数据库启用后的路由

- `ConfigStore`：定义类文档 → `config_documents`（按 profile）
- `USER` 类（`UserRepository`）：`users` + `user_pending_xp` → 挂起经验入库
- `ServerSettingsStore`：调参覆盖 → `server_settings`（`applyDbOverrides`）
- `AssetRepository`：素材入库管理
- 多配置档：`config_profiles` 表 + `meta.active_profile`；`/rp db profile` 切换，各 Manager 热重载
- 未启用：一切维持文件行为，零破坏。

### 7.3 原子写与容错

- 全部 JSON 写 = 临时文件（`*.tmp`）→ `Files.move(ATOMIC_MOVE)` → rename；
- 解析失败写 ERROR 日志 + **跳过该文件继续运行**（服务不崩溃）；
- 损坏文件保留 `.bak` 备份。

---

## 8. 运行方式

### 8.1 安装（玩家视角）

1. Forge 47.2.0+（MC 1.20.1）启动器 → 把 `ccnr_rp-2.19.5.jar` 放入 `mods/`。
2. 首次启动生成默认配置 `config/ccnr_rp/*.json`（3 样例阵营 + 4 样例职业）。
3. `K` 键打开角色管理终端；R 键打开招募弹窗。
4. 服务器与客户端**同一版本**；阵营/职业/阶段/事件以**服务器**侧配置为准（客户端只有本机单人模式配置生效）。

### 8.2 构建（开发者）

```bash
export JAVA_HOME=<JDK21 路径>                      # 构建需 JDK 21
export GRADLE_USER_HOME=<共享 gradle 缓存目录>      # 建议复用 CCNR 系列缓存
./scripts/fetch-corpse.sh                          # 拉取 Corpse 编译期依赖 → libs/（已存在跳过）
./gradlew build                                    # compileJava(-Xlint:all) + spotlessCheck 门禁 → build/libs/ccnr_rp-*.jar
./gradlew test -PrunTests                          # 显式开启单测（离线默认不跑）
./gradlew spotlessApply                            # 提交前格式化入口
./gradlew runServer / ./gradlew runClient          # 开发环境一键启动
```

> 国内镜像已内置：Gradle 发行版走腾讯云，Maven Central 走阿里云。
> `-PrunTests` 是唯一测试开关（`onlyIf { project.hasProperty('runTests') }`）。

### 8.3 常用命令（/rp）

| 分类 | 示例 |
| --- | --- |
| 阵营 | `/rp faction relation <a> <b> set <type>`、`/rp faction group relation <g1> <g2> <type>` |
| 职业 | `/rp profession list`、`/rp profession save <id> [--hotbar|--full]`、`/rp profession load <id>` |
| 用户/状态 | `/rp state`、`/rp kill <player>`、`/rp character create/select/observe/activate` |
| 经验 | `/rp xp add <player> <value> <title>`、`/rp settle all`、`/rp level` |
| 事件/阶段 | `/rp event trigger <id>`、`/rp phase set <id>`、`/rp gameover` |
| 动画/刷新 | `/rp animation play <id>`、`/rp spawn trigger <id>` |
| 数据库 | `/rp db status|test|migrate|export|flush|connect|profile` |
| 管理面板 | `/rp gui`（打开管理终端） |

### 8.4 CI（.github/workflows/build.yml）

`main` push / PR / `v*` 标签触发：JDK21(temurin) + Gradle cache → `fetch-corpse.sh` → `./gradlew build`（含 spotlessCheck）→ `test -PrunTests` → 上传产物；打 `v*` 标签时自动 `gh release upload` 附加 jar。

---

## 9. 测试体系

JUnit5（`-PrunTests` 门控），覆盖**纯逻辑层**与少量集成，共 30+ 测试类：

| 模块 | 测试 |
| --- | --- |
| animation | `AnimationModelsTest` |
| client | `ClientCharacterStateTest`、`ProfileDataFlowTest` |
| data | `AssetRepositoryTest`、`ConfigStoreTest`、`DbConfigTest`、`SqlDialectTest`、`SqlMapperTest`、`UserRepositoryTest` |
| event | `PhaseClockTest`、`TriggerEvaluatorTest` |
| experience | `ExperienceEventRegistryTest`、`ExperienceRuleTest`、`ExprTest`、`KillRelationTest`、`LevelCurveTest`、`XpChangeListTest` |
| faction | `FactionGraphTest`、`FactionManagerSaveTest`、`FactionProfessionsTest` |
| music | `MusicStoreTest` |
| profession | `NbtCodecTest`、`ProfessionJsonTest` |
| spawn | `DeployLimitsTest`、`SpawnModelsTest` |
| status | `StatusMachineTest` |
| 工程基线 | `LangFileTest`（zh_cn/en_us 键同步，漏翻红字）、`ProjectMetadataTest`（mods.toml 同步） |

---

## 10. 设计与工程约定

1. **服务端权威**：客户端只发意图；服务端校验距离/权限/参数/世界有效性；同步用增量 + 追踪（晚加入/重进/重连拿到当前有效状态）。
2. **幂等判死**：掉线判死有事件 + 轮询两条路径，重复触发只处理一次。
3. **对称清理**：资源/线程/监听/缓存对称创建释放；世界卸载/维度切换/配置重载/关服/断线都是必做清理路径
   （见 `onServerStopping` 全量注销、`clearDeathSpots`、`shutdownBroadcaster`、`STREAMER` daemon 线程等）。
4. **线程边界**：独立线程只碰纯数据/不可变快照；Level/NBT/网络/渲染必须回主线程；结果提交前校验新鲜度。
5. **数据驱动优先**：一切定义（阵营/职业/阶段/事件/动画/刷新波/经验规则/限制）均 JSON 化、可热重载。
6. **规范门禁**：`-Xlint:all`、spotless（palantirJavaFormat + license 头）、`LangFileTest` / `ProjectMetadataTest` 基线测试。
7. **公共契约**：`player_spawn / player_death / game_end / event_start / level_up` 是跨系统钩子契约，变更必须先改文档。
8. **可选联动降级**：Corpse/CMDCam/LDLib 均为可选——`ModList` 探测 + 缺失降级（原生死亡 / 无场景 / 简化 UI）。

---

*文档生成时间：2026-09-01；依据仓库 HEAD（v2.19.5）源码。*