# CCNR-RP 模组 Code Wiki

> 本文档基于 `v2.19.0+` 源码生成，覆盖项目架构、模块职责、关键类/函数、依赖关系及运行方式。

***

## 目录

1. [项目概述](#1-项目概述)
2. [技术栈](#2-技术栈)
3. [目录结构](#3-目录结构)
4. [架构总览](#4-架构总览)
5. [核心模块详解](#5-核心模块详解)

   * [5.1 模组入口 - CCNRRPMod](#51-模组入口---ccnrrpmod)

   * [5.2 配置系统](#52-配置系统)

   * [5.3 数据库后端](#53-数据库后端)

   * [5.4 阵营系统](#54-阵营系统)

   * [5.5 角色系统](#55-角色系统)

   * [5.6 用户系统](#56-用户系统)

   * [5.7 状态管理](#57-状态管理)

   * [5.8 经验系统](#58-经验系统)

   * [5.9 事件系统](#59-事件系统)

   * [5.10 刷新框架](#510-刷新框架)

   * [5.11 动画引擎](#511-动画引擎)

   * [5.12 序列引擎](#512-序列引擎)

   * [5.13 素材库](#513-素材库)

   * [5.14 网络通道](#514-网络通道)

   * [5.15 命令系统](#515-命令系统)

   * [5.16 Corpse 联动](#516-corpse-联动)

   * [5.17 客户端](#517-客户端)

   * [5.18 工具与权限](#518-工具与权限)
6. [关键数据流](#6-关键数据流)
7. [配置文件清单](#7-配置文件清单)
8. [开发与构建](#8-开发与构建)
9. [测试体系](#9-测试体系)
10. [依赖关系图](#10-依赖关系图)

***

## 1. 项目概述

**CCNR-RP** 是一个 Minecraft Forge 1.20.1 角色扮演（RolePlay）模组，为 CCNR 服务器提供完整的角色扮演体系。核心功能包括：

* **阵营系统**：多阵营-多组关系图，支持自定义关系规则（友好/中立/敌对）

* **角色/职业系统**：用户可选择的职业（Profession），含装备预设（Loadout）、等级门槛

* **状态管理**：三态角色状态机（ALIVE → DEAD → OBSERVING → ALIVE），含冷却、掉线判死

* **经验系统**：事件驱动规则引擎，可配置经验规则、等级曲线、升级特效

* **事件系统**：阶段时钟 + 触发器引擎，支持多类型事件触发与自动生命周期

* **刷新框架**：征召波系统，支持自部署/复活波/强制征召，含名额分配与冷却

* **动画引擎**：服务端驱动的多步动画序列（Title/ActionBar/粒子/音效/摄像机）

* **序列引擎**：顺序执行多步行为序列（等待/刷新波/命令/强制征召），支持变量注入

* **素材同步**：服务端权威下发音频/纹理素材，客户端按需下载缓存

* **数据库后端**：可选的 SQLite/MySQL 持久化支持，配置文件多档管理

* **Corpse 联动**：与 Corpse 模组可选集成，死亡身份注入与名字牌

***

## 2. 技术栈

| 层面   | 技术                            |
| ---- | ----------------------------- |
| 游戏平台 | Minecraft Forge 1.20.1        |
| 语言   | Java 21                       |
| 构建工具 | Gradle 8.x                    |
| 映射   | Official mappings (Mojang)    |
| 代码风格 | Spotless (Google Java Format) |
| 混入   | Mixin 0.8.5                   |
| 数据库  | SQLite (内置) / MySQL (可选)      |
| 测试   | JUnit 5                       |
| 日志   | Log4j 2 (SLF4J)               |

***

## 3. 目录结构

```
CCNR-RP/
├── build.gradle                  # 主构建脚本
├── settings.gradle               # Gradle 设置
├── gradle.properties             # 构建属性
├── AGENTS.md                     # AI 开发助手指南
├── CHANGELOG.md                  # 版本变更日志
├── README.md                     # 项目说明
├── LICENSE                       # MIT 许可证
├── .editorconfig                 # 编辑器配置
├── .gitignore                    # Git 忽略规则
├── .github/                      # CI/CD 工作流
├── config/                       # 运行时配置输出目录
├── docs/                         # 文档
│   ├── 00-overview.md            # 项目总览
│   ├── 01-conventions.md         # 开发规范
│   ├── 02-config.md              # 配置文档
│   ├── 03-factions.md            # 阵营文档
│   ├── 04-characters.md          # 角色文档
│   ├── 05-experience.md          # 经验文档
│   ├── 06-events.md              # 事件文档
│   ├── 07-animations.md          # 动画文档
│   ├── 08-hooks.md               # 钩子契约
│   ├── 09-spawn.md               # 刷新文档
│   ├── 10-commands.md            # 命令文档
│   ├── 11-network.md             # 网络文档
│   ├── 12-database.md            # 数据库文档
│   └── code-wiki.md              # ← 本文档
├── gradle/                       # Gradle Wrapper
├── libs/                         # 编译期依赖 (Corpse jar)
├── scripts/
│   └── fetch-corpse.sh           # 下载 Corpse 依赖脚本
├── src/
│   ├── main/java/com/ccnrcom/rp/
│   │   ├── CCNRRPMod.java        # 模组入口
│   │   ├── animation/            # 动画引擎
│   │   ├── assets/               # 素材库
│   │   ├── character/            # 角色服务
│   │   ├── client/               # 客户端逻辑
│   │   ├── command/              # 命令系统
│   │   ├── config/               # 配置管理
│   │   ├── corpse/               # Corpse 联动
│   │   ├── data/                 # 数据库后端
│   │   │   └── orm/              # 微 ORM
│   │   ├── event/                # 事件系统
│   │   ├── experience/           # 经验系统
│   │   ├── faction/              # 阵营系统
│   │   ├── mixins/               # Mixin 注入
│   │   ├── network/              # 网络通道
│   │   ├── sequence/             # 序列引擎
│   │   ├── spawn/                # 刷新框架
│   │   ├── status/               # 状态管理
│   │   ├── user/                 # 用户系统
│   │   └── util/                 # 工具类
│   ├── main/resources/
│   │   ├── META-INF/mods.toml    # 模组元数据
│   │   ├── pack.mcmeta           # 资源包描述
│   │   ├── ccnr_rp.mixins.json   # Mixin 配置
│   │   └── assets/ccnr_rp/
│   │       ├── lang/             # 语言包 (zh_cn/en_us)
│   │       ├── defaults/         # 默认配置
│   │       │   ├── events.json
│   │       │   └── spawn_waves.json
│   │       └── shaders/          # 自定义着色器
│   └── test/java/com/ccnrcom/rp/ # 测试代码
│       ├── animation/
│       ├── data/
│       ├── event/
│       ├── experience/
│       ├── faction/
│       ├── music/
│       ├── profession/
│       ├── spawn/
│       ├── status/
│       ├── LangFileTest.java
│       └── ProjectMetadataTest.java
```

***

## 4. 架构总览

### 4.1 分层架构

```
┌─────────────────────────────────────────────────────────┐
│                      命令层 (command)                     │
│   RpCommand / FactionCommand / XpCommand / DbCommand ... │
├─────────────────────────────────────────────────────────┤
│                      服务层 (Services)                    │
│   CharacterService / UserService / ExperienceService     │
│   StatusManager / EventManager / SpawnFramework          │
│   AnimationEngine / SequenceEngine                       │
├─────────────────────────────────────────────────────────┤
│                      逻辑层 (Pure Logic)                  │
│   FactionGraph / StatusMachine / LevelCurve / Expr       │
│   EventModels / SpawnModels / DeployLimits / WaveQuota   │
├─────────────────────────────────────────────────────────┤
│                    数据层 (Data)                          │
│   Database / DbSchema / ConfigStore / UserRepository     │
│   AssetRepository / SqlMapper (微 ORM)                   │
├─────────────────────────────────────────────────────────┤
│                   网络层 (Network)                        │
│   RpChannels / RpPackets (C2S & S2C 双向)                │
└─────────────────────────────────────────────────────────┘
```

### 4.2 关键设计原则

* **服务端权威**：所有状态由服务端维护，客户端只发意图，服务端重新校验所有参数

* **纯逻辑可测**：核心规则（阵营关系图、状态机、等级曲线、经验规则引擎）无 MC 导入，可直接 JUnit 测试

* **存储分层**：serverconfig toml = 调参；config JSON = 管理员可编辑定义；数据库（可选）= 运行时持久化

* **对称清理**：资源/线程/监听器/网络追踪对称创建释放，`ServerStopping` 清空所有服务

* **数据驱动**：阵营/职业/事件/动画/刷新波等全部通过 JSON 配置文件定义

***

## 5. 核心模块详解

### 5.1 模组入口 - CCNRRPMod

**文件**: [CCNRRPMod.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/CCNRRPMod.java)

`@Mod(CCNRRPMod.MODID)` 标注的模组主类，`MODID = "ccnr_rp"`。

#### 静态字段（全局服务实例）

| 字段                | 类型                  | 说明           |
| ----------------- | ------------------- | ------------ |
| `factions`        | `FactionManager`    | 阵营配置管理器      |
| `managerSettings` | `ManagerSettings`   | 管理器设置（入服规则等） |
| `sequenceEngine`  | `SequenceEngine`    | 序列引擎         |
| `characters`      | `CharacterService`  | 角色服务         |
| `users`           | `UserService`       | 用户服务         |
| `statusManager`   | `StatusManager`     | 状态管理         |
| `experience`      | `ExperienceService` | 经验服务         |
| `eventManager`    | `EventManager`      | 事件管理         |
| `spawnFramework`  | `SpawnFramework`    | 刷新框架         |
| `animationEngine` | `AnimationEngine`   | 动画引擎         |
| `database`        | `Database`          | 数据库后端        |

#### 生命周期回调

| 事件                        | 方法                       | 说明                                                                           |
| ------------------------- | ------------------------ | ---------------------------------------------------------------------------- |
| 构造                        | `CCNRRPMod()`            | 注册 server config、mod bus 监听、通道注册                                             |
| `FMLCommonSetupEvent`     | `commonSetup()`          | 公共初始化日志                                                                      |
| `RegisterCommandsEvent`   | `onRegisterCommands()`   | 注册 `/rp` 命令树                                                                 |
| `ServerAboutToStartEvent` | `onServerAboutToStart()` | **核心装配**：初始化 DB → 配置覆盖 → 阵营 → 角色 → 用户 → 状态 → Corpse → 经验 → 刷新 → 动画 → 事件 → 序列 |
| `PlayerLoggedInEvent`     | `onPlayerLoggedIn()`     | 首次入服入队、状态归一化、角色列表同步、素材同步、死亡旁观、补发通知                                           |
| `PlayerLoggedOutEvent`    | `onPlayerLoggedOut()`    | 清理素材标记、取消招募、刷新玩家标签                                                           |
| `ServerStoppingEvent`     | `onServerStopping()`     | 对称清理所有服务（逆序）                                                                 |

#### 服务装配顺序（关键）

```
Database.connect() → CCNRRPConfig.applyDbOverrides() → ManagerSettings
→ AssetLibrary.ensureDefaults() → FactionManager.load()
→ CharacterService → UserService → StatusManager → CorpseBridge
→ ExperienceService → SpawnFramework → AnimationEngine
→ EventManager → SequenceEngine
```

***

### 5.2 配置系统

#### 5.2.1 serverconfig TOML 调参

**文件**: [CCNRRPConfig.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/config/CCNRRPConfig.java)

基于 Forge `ForgeConfigSpec` 构建，配置文件位于 `serverconfig/ccnr_rp-server.toml`。

**主要配置项**：

| 配置键                             | 类型     | 默认值 | 说明          |
| ------------------------------- | ------ | --- | ----------- |
| `deathCooldownMinutes`          | int    | 30  | 死亡冷却时间（分钟）  |
| `disconnectDeathTimeoutSeconds` | int    | 120 | 掉线判死超时      |
| `eventPollIntervalTicks`        | int    | 100 | 事件轮询间隔 tick |
| `deployDelayTicks`              | int    | 60  | 部署延迟        |
| `levelCurveBase`                | int    | 100 | 等级曲线基数      |
| `levelCurveFactor`              | double | 1.5 | 等级曲线系数      |
| `killXpBase`                    | int    | 50  | 击杀经验基础值     |
| `killXpLevelMultiplier`         | int    | 5   | 击杀经验等级系数    |
| `xpDisplayIntervalTicks`        | int    | 20  | HUD 经验显示间隔  |

**关键 API**：

* `keys()` — 返回所有配置键（展示顺序）

* `values()` — 返回当前所有配置值

* `set(key, value)` — 写入配置并持久化

* `applyDbOverrides()` — 数据库启用时从 `server_settings` 表覆盖运行时值

#### 5.2.2 ManagerSettings

**文件**: [ManagerSettings.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/config/ManagerSettings.java)

管理面板设置，存储在 `settings.json` 或数据库 `config_documents` 表。

| 字段                    | 类型      | 默认值   | 说明       |
| --------------------- | ------- | ----- | -------- |
| `enforceRules`        | boolean | true  | 强制入服规则   |
| `forceRetain`         | int     | 0     | 强制保留人数   |
| `firstJoinAutoDeploy` | boolean | false | 首次入服自动部署 |
| `firstJoinProfession` | String  | ""    | 首次入服默认职业 |

***

### 5.3 数据库后端

#### 5.3.1 Database 门面

**文件**: [Database.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/data/Database.java)

数据库生命周期与访问门面，支持 SQLite 和 MySQL。

**核心特性**：

* **单一连接 + ReentrantLock** 串行化访问（服务端权威模型下足够）

* **写操作专用单线程 Executor**（不阻塞主线程）

* **读操作主线程同步**（`read()` 加锁执行）

* **未启用时全部方法为空操作**

**关键 API**：

| 方法                     | 说明                |
| ---------------------- | ----------------- |
| `connect()`            | 建立连接 + 初始化 schema |
| `disconnect()`         | 关闭连接 + 停止写线程      |
| `read(SqlRead<T>)`     | 主线程同步读            |
| `write(SqlWrite)`      | 主线程同步写            |
| `asyncWrite(SqlWrite)` | 后台异步写             |

#### 5.3.2 DbConfig 配置

**文件**: [DbConfig.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/data/DbConfig.java)

从 `config/db.properties` 读取数据库连接配置，支持：

* `db.enabled` — 启用/禁用

* `db.mode` — sqlite / mysql

* `db.profile` — 配置档名（多配置档支持）

* `db.jdbc_url` / `db.user` / `db.password` — JDBC 连接参数

* 密码支持环境变量引用 `${ENV_VAR}`

#### 5.3.3 DbSchema

**文件**: [DbSchema.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/data/DbSchema.java)

定义数据库 DDL 表结构，幂等创建。主要表：

| 表名                 | 说明              |
| ------------------ | --------------- |
| `schema_version`   | Schema 版本追踪     |
| `meta`             | 元数据存储           |
| `config_profiles`  | 配置档定义           |
| `config_documents` | 配置文档（JSON 配置内容） |
| `users`            | 用户档案            |
| `user_pending_xp`  | 待处理经验           |
| `pending_notices`  | 待补发通知           |
| `team_waves_done`  | 队伍已刷新波次         |
| `server_settings`  | 服务端调参覆盖         |
| `assets`           | 素材 BLOB 存储      |

#### 5.3.4 微 ORM

**文件**: [SqlMapper.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/data/orm/SqlMapper.java)

基于注解的轻量级 ORM，针对 Java record 类型：

| 注解              | 说明                     |
| --------------- | ---------------------- |
| `@Table(name)`  | 标记实体对应的数据库表名           |
| `@Column(name)` | 映射字段到列                 |
| `@Id`           | 标记主键字段                 |
| `@JsonColumn`   | JSON 序列化列（自动 JSON 编解码） |
| `@Blob`         | 二进制大对象列                |

#### 5.3.5 SqlDialect

**文件**: [SqlDialect.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/data/SqlDialect.java)

SQL 方言适配层，统一 `?` 占位符和标识符引用，为 SQLite/MySQL 差异化生成：

* `upsert(table, columns, key)` — 生成 UPSERT 语句

* `createTable(table, columns, spec)` — 生成 CREATE TABLE 语句

#### 5.3.6 仓储层

| 类                 | 文件                                                                                                                                                | 说明                |
| ----------------- | ------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------- |
| `UserRepository`  | [UserRepository.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/data/UserRepository.java)   | 用户档案与待处理经验读写      |
| `AssetRepository` | [AssetRepository.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/data/AssetRepository.java) | 素材 BLOB 元数据/读写/删除 |
| `ConfigStore`     | [ConfigStore.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/data/ConfigStore.java)         | 配置文档存储（DB/磁盘双后端）  |

***

### 5.4 阵营系统

#### 5.4.1 FactionManager

**文件**: [FactionManager.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/faction/FactionManager.java)

阵营配置管理器，负责 `config/ccnr_rp/factions.json` 的加载、解析、保存。

**关键 API**：

| 方法                                                                   | 说明             |
| -------------------------------------------------------------------- | -------------- |
| `load()`                                                             | 加载阵营配置，缺失时生成默认 |
| `graph()`                                                            | 返回当前阵营关系图      |
| `hasFactionOrGroup(String id)`                                       | 检查阵营/组是否存在     |
| `setRelation(String a, String b, String relation)`                   | 设置单对关系并落盘      |
| `updateFaction(String id, JsonObject update)`                        | 更新阵营配置         |
| `setProfessionLoadout(String id, String profId, JsonObject loadout)` | 设置职业装备预设       |
| `setProfessionSpawn(String id, String profId, JsonObject spawn)`     | 设置职业刷新生点       |

#### 5.4.2 FactionGraph

**文件**: [FactionGraph.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/faction/FactionGraph.java)

**纯逻辑**，无 MC 依赖。阵营关系图引擎，支持多对多关系解析。

**核心规则**：

* `resolve(a, b)` — 按声明顺序命中关系规则，未命中返回 `NEUTRAL`

* 同一阵营内关系恒为 `FRIENDLY`

* 支持组（Group）与阵营（Faction）混合关系

* 重复声明覆盖警告

#### 5.4.3 FactionModels

**文件**: [FactionModels.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/faction/FactionModels.java)

阵营领域模型：

| Record         | 字段                                         | 说明       |
| -------------- | ------------------------------------------ | -------- |
| `Faction`      | id, name, color, groupId, professions      | 阵营定义     |
| `FactionGroup` | id, name, color                            | 阵营组      |
| `RelationRule` | subject, target, relation                  | 关系规则     |
| `RelationEdge` | a, b, relation                             | 关系边（已解析） |
| `ParseResult`  | factions, groups, relations, edges, errors | 解析结果     |

#### 5.4.4 FactionProfessions

**文件**: [FactionProfessions.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/faction/FactionProfessions.java)

职业配置管理，提供 `upsertProfession()` 方法进行职业数据的增改，含 `cmdcamScene`、`radio`、`profile`、`music` 等字段处理。

***

### 5.5 角色系统

**文件**: [CharacterService.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/character/CharacterService.java)

角色服务，管理玩家角色选择、部署、标签等。

**关键 API**：

| 方法                              | 说明                             |
| ------------------------------- | ------------------------------ |
| `sendList(ServerPlayer player)` | 发送角色列表给客户端                     |
| `broadcastPlayerTags()`         | 广播所有玩家头顶标签                     |
| `onSelectCharacter(C2S 包)`      | 处理角色选择请求                       |
| `onDeployPosition(C2S 包)`       | 处理自刷新部署请求（校验：素材同步、观察态、冷却、职位等级） |
| `onKillDeploy(C2S 包)`           | 处理重新部署请求（ALIVE 态可用）            |
| `onServerConfigSet(C2S 包)`      | 处理管理面板配置设置                     |
| `shutdownBroadcaster()`         | 关闭配置广播后台线程                     |

***

### 5.6 用户系统

**文件**: [UserService.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/user/UserService.java)

用户体系：一个玩家 UUID 对应一个用户档案，数据持久化到 `user_profiles.json` 或数据库。

**用户数据结构**：

| 字段            | 类型                | 说明                   |
| ------------- | ----------------- | -------------------- |
| status        | `CharacterStatus` | ALIVE/DEAD/OBSERVING |
| professionId  | String            | 当前职业 ID              |
| factionId     | String            | 当前阵营 ID              |
| totalXp       | long              | 总经验值                 |
| level         | int               | 等级                   |
| cooldownUntil | long              | 冷却截止时间戳              |
| dutyMinutes   | long              | 执勤时长                 |
| pendingXp     | `List<XpChange>`  | 待结算经验列表              |

**关键 API**：

| 方法                                             | 说明           |
| ---------------------------------------------- | ------------ |
| `status(uuid)`                                 | 获取用户状态       |
| `setStatus(uuid, status)`                      | 设置状态（触发标签广播） |
| `professionId(uuid)`                           | 获取当前职业       |
| `cooldownUntil(uuid)` / `onCooldown(uuid)`     | 冷却查询         |
| `addXp(uuid, xp)`                              | 增加总经验        |
| `pendingXp(uuid)` / `setPendingXp(uuid, list)` | 待结算经验管理      |
| `save()`                                       | 持久化所有用户数据    |

***

### 5.7 状态管理

#### 5.7.1 CharacterStatus 枚举

**文件**: [CharacterStatus.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/status/CharacterStatus.java)

```
ALIVE     → 存活（在场，可正常游戏）
DEAD      → 死亡（等待复活/冷却）
OBSERVING → 观察者（阴间/旁观）
```

#### 5.7.2 StatusMachine 状态机

**文件**: [StatusMachine.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/status/StatusMachine.java)

**纯逻辑**，无 MC 依赖。

**状态迁移规则**：

```
OBSERVING → ALIVE     : 自部署/复活波
ALIVE     → DEAD      : 死亡/判死
ALIVE     → OBSERVING : 退役/管理员强制
DEAD      → ALIVE     : 复活波
```

**关键 API**：

| 方法                        | 说明                        |
| ------------------------- | ------------------------- |
| `canTransition(from, to)` | 是否允许迁移                    |
| `canSelfDeploy(status)`   | 能否自部署（仅 OBSERVING）        |
| `canWaveEligible(status)` | 能否收到复活波邀请（DEAD/OBSERVING） |

#### 5.7.3 StatusManager

**文件**: [StatusManager.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/status/StatusManager.java)

状态管理主类，注册到 Forge 事件总线。

**关键职责**：

* **死亡事件主路径**：击杀经验广播、死亡通知、状态迁移、遗体生成

* **掉线判死**：`PlayerEvent.PlayerLoggedOutEvent` 启动定时器，超时后判死

* **统一退场**：`retire()` 方法根据 `RetireFlag` 控制死亡/判死/退役行为

* **死亡点追踪**：`deathSpots` 记录死亡位置，`clearDeathSpots()` 对称清理

***

### 5.8 经验系统

#### 5.8.1 ExperienceService

**文件**: [ExperienceService.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/experience/ExperienceService.java)

经验系统 v3，事件驱动规则引擎。

**架构**：

```
事件广播 → 规则引擎 → 待结算 XP 列表 → 结算 → 等级更新 + HUD 推送
```

**关键 API**：

| 方法                                                      | 说明                              |
| ------------------------------------------------------- | ------------------------------- |
| `loadRules()`                                           | 加载 `experience_rules.json`，编译规则 |
| `addRule(rule)` / `updateRule(rule)` / `removeRule(id)` | 规则 CRUD                         |
| `reloadRules()`                                         | 热重载规则                           |
| `onEvent(event, context)`                               | 事件触发 → 规则匹配 → 产生 XP 变化          |
| `settle(uuid)`                                          | 结算待处理 XP → 更新等级 → HUD 动画        |
| `flushPending(ServerPlayer)`                            | 补发离线结算通知                        |
| `rulesPayload()`                                        | 当前规则集 JSON 负载（同步给客户端管理面板）       |

**经验规则结构**：

```json
{
  "id": "kill_priority",
  "enabled": true,
  "event": "PLAYER_KILL",
  "condition": "target.relation == 'HOSTILE'",
  "value": "50 + killer.level * 5",
  "title": "击杀敌对目标",
  "description": "击杀敌对阵营成员获得经验"
}
```

#### 5.8.2 ExperienceModels

**文件**: [ExperienceModels.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/experience/ExperienceModels.java)

经验领域模型：

| Record           | 说明                                            |
| ---------------- | --------------------------------------------- |
| `ExperienceRule` | 经验规则（id, event, condition, value, title, ...） |
| `XpChange`       | 经验变化（ruleId, amount, title, timestamp）        |
| `XpChangeList`   | 经验变化列表（合并、排序、求和）                              |

#### 5.8.3 Expr 表达式引擎

**文件**: [Expr.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/experience/Expr.java)

**纯逻辑**，无 MC 依赖。轻量级表达式引擎，支持：

* 算术运算：`+ - * / %`

* 比较运算：`== != < > <= >=`

* 逻辑运算：`&& || !`

* 三元表达式：`cond ? trueVal : falseVal`

* 函数调用：`min() max() clamp()`

* 变量注入：`${variableName}`

* 字符串拼接：`+`

* 括号分组

#### 5.8.4 LevelCurve

**文件**: [LevelCurve.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/experience/LevelCurve.java)

**纯逻辑**，无 MC 依赖。

* `xpForLevel(level)` — 计算升到指定等级所需总经验

* `level(totalXp)` — 根据总经验反推等级

* `canLevelUp(totalXp, currentLevel)` — 是否可以升级

使用指数曲线公式：`base * (factor ^ level)`，base 和 factor 由 `CCNRRPConfig` 配置。

#### 5.8.5 PendingNoticeStore

**文件**: [PendingNoticeStore.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/experience/PendingNoticeStore.java)

离线结算通知暂存，上线后补发：

* `store(notice)` — 记录待补发通知

* `drain(player)` — 取出并删除玩家通知

* `save()` — 持久化到 DB / 磁盘

***

### 5.9 事件系统

#### 5.9.1 EventManager

**文件**: [EventManager.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/event/EventManager.java)

事件管理引擎，P6 完整实现。

**流程**：

```
阶段时钟推进 → 触发器求值 → 事件生命周期 (SCHEDULED → RUNNING → SETTLED)
```

**关键 API**：

| 方法                          | 说明                               |
| --------------------------- | -------------------------------- |
| `loadEvents()`              | 加载 `events.json` / `phases.json` |
| `tick(ServerLevel level)`   | 服务端主循环（阶段时钟 + 触发器求值 + 自动结束）      |
| `startEvent(definition)`    | 启动事件（衔接动画/刷新波/行为序列）              |
| `endEvent(id)`              | 结束事件                             |
| `autoEndRunnings(long now)` | 超时自动结束                           |

#### 5.9.2 EventModels

**文件**: [EventModels.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/event/EventModels.java)

**纯逻辑**，无 MC 依赖。

**核心模型**：

| Record/Enum       | 说明                                                                     |
| ----------------- | ---------------------------------------------------------------------- |
| `GamePhase`       | 游戏阶段（id, order, durationMinutes, steps）                                |
| `Trigger`         | 触发器（type + params）                                                     |
| `Trigger.Type`    | `ON_PHASE_START / ON_PHASE_END / ON_TIME / PERIODIC / CONDITION`       |
| `EventDefinition` | 事件定义（triggers, tasks, startAnimation, spawnWave, durationSeconds, ...） |
| `EventState`      | `SCHEDULED → RUNNING → SETTLED`                                        |
| `TriggerContext`  | 触发器求值上下文（快照式纯数据）                                                       |
| `Task`            | 事件任务（id, xp）                                                           |

**触发器类型详解**：

| 类型               | 参数              | 说明                                           |
| ---------------- | --------------- | -------------------------------------------- |
| `ON_PHASE_START` | phase           | 指定阶段开始时触发                                    |
| `ON_PHASE_END`   | phase           | 指定阶段结束时触发                                    |
| `ON_TIME`        | day, tickOfDay  | 指定游戏时间触发                                     |
| `PERIODIC`       | seconds         | 周期性触发                                        |
| `CONDITION`      | cond, op, value | 条件满足时触发（DEAD\_COUNT/ALIVE\_COUNT/SCOREBOARD） |

#### 5.9.3 PhaseClock

**文件**: [PhaseClock.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/event/PhaseClock.java)

阶段时钟：按 `durationMinutes` 推进阶段，产生 `Transition(changed, started, ended)`。

#### 5.9.4 TriggerEvaluator

**文件**: [TriggerEvaluator.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/event/TriggerEvaluator.java)

**纯逻辑**，无 MC 依赖。触发器求值器，实现五种触发类型的判定逻辑。

***

### 5.10 刷新框架

#### 5.10.1 SpawnFramework

**文件**: [SpawnFramework.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/spawn/SpawnFramework.java)

P8 刷新框架，处理自刷新、召唤波、招募兜底链路。

**流程**：

```
事件/序列触发 → 波选择 → 候选过滤 → 名额分配 → 邀请 → 部署
```

**关键 API**：

| 方法                            | 说明                    |
| ----------------------------- | --------------------- |
| `loadWaves()`                 | 加载 `spawn_waves.json` |
| `triggerWave(waveId, server)` | 按 ID 触发刷新波            |
| `redeploy(player, wave)`      | 重新部署（ALIVE 态）         |
| `recruit()`                   | 返回招募管理器               |
| `recruitConscript(conscript)` | 强制征召                  |
| `maybeQueueFirstJoin(player)` | 首次入服自动部署入队            |
| `onPlayerDisconnect(uuid)`    | 取消玩家招募邀请              |

#### 5.10.2 SpawnModels

**文件**: [SpawnModels.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/spawn/SpawnModels.java)

**纯逻辑**，无 MC 依赖。

| Record/Enum           | 说明                                                            |
| --------------------- | ------------------------------------------------------------- |
| `Mode`                | `SELF_DEPLOY / RESURRECTION / BOTH`（波接收模式）                    |
| `ConscriptDeployMode` | `TEMP / FORMAL / SKIP`（征召部署方式）                                |
| `WaveQuota`           | 名额分配（aliveShare, pickTarget）                                  |
| `Wave`                | 波定义（teamIds, professionIds, factionIds, count, deployAt, ...） |
| `Candidate`           | 选人候选（charId, status, level, online, ...）                      |
| `Selection`           | 选人结果（deploy, recruit）                                         |

**名额分配逻辑** (`WaveQuota.split`)：

1. `count <= 0` → 跳过
2. 存活征召先取 `ceil(count/2)`
3. 剩余归观察者选岗
4. 某一通道无候选时该通道不发邀请（名额不转移）

#### 5.10.3 DeployLimits

**文件**: [DeployLimits.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/spawn/DeployLimits.java)

**纯逻辑**，无 MC 依赖。部署人数限制，按 profession/faction/global 维度检查上限。

#### 5.10.4 DeployFlag

**文件**: [DeployFlag.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/spawn/DeployFlag.java)

部署行为 flags 枚举，控制自部署、管理员刷人、复活波、强制征召等行为差异。

***

### 5.11 动画引擎

#### 5.11.1 AnimationEngine

**文件**: [AnimationEngine.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/animation/AnimationEngine.java)

服务端动画引擎，加载 `animations.json`，绑定钩子，分发动画序列到客户端。

**关键 API**：

| 方法                                         | 说明             |
| ------------------------------------------ | -------------- |
| `load()`                                   | 加载动画配置         |
| `play(sequenceId, players)`                | 播放动画序列到指定玩家    |
| `playHook(hook, level, players)`           | 按钩子播放绑定动画      |
| `inject(template, ctx)`                    | 变量注入 `${name}` |
| `sequenceToJson(seq)` / `stepToJson(step)` | 序列化动画包         |

**支持的动画步骤类型**：

| 类型          | 说明        |
| ----------- | --------- |
| `TITLE`     | 标题/副标题显示  |
| `ACTIONBAR` | 操作栏显示     |
| `FADE`      | 淡入淡出      |
| `CAMERA`    | 摄像机路径（单点） |
| `CAMS`      | 摄像机序列     |
| `PARTICLE`  | 粒子效果      |
| `SOUND`     | 音效播放      |
| `GROUP`     | 子步骤组      |

#### 5.11.2 AnimationModels

**文件**: [AnimationModels.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/animation/AnimationModels.java)

**纯逻辑**，无 MC 依赖。动画序列模型与 JSON 解析：

| Record     | 说明                                |
| ---------- | --------------------------------- |
| `Step`     | 动画步骤（type, params, durationTicks） |
| `Sequence` | 动画序列（id, hook, steps）             |

#### 5.11.3 AnimationHooks

**文件**: [AnimationHooks.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/animation/AnimationHooks.java)

动画钩子公共契约，定义钩子入口：

* `player_spawn` — 玩家部署

* `player_death` — 玩家死亡

* `event_start` — 事件开始

* `game_end` — 游戏结束

* `level_up` — 玩家升级

***

### 5.12 序列引擎

**文件**: [SequenceEngine.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/sequence/SequenceEngine.java)

顺序执行行为序列，支持 `{{变量}}` 注入。

**支持的步骤类型**：

| 类型           | 说明          |
| ------------ | ----------- |
| `WAIT`       | 等待指定时长      |
| `WAVE`       | 触发刷新波       |
| `COMMAND`    | 执行命令        |
| `FORCE_PICK` | 强制征召（临时征召兵） |

**核心流程**：

```
1. 从 sequences.json 加载序列定义
2. 启动序列 → 解析 steps → 注入变量 → 入队
3. 服务端 tick 按 dueAtMs 逐步执行
4. 全部完成 → 清理
```

***

### 5.13 素材库

**文件**: [AssetLibrary.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/assets/AssetLibrary.java)

服务端权威素材库，管理 `audio/*.ogg` 与 `textures/*.png`。

**流程**：

```
服务端生成清单 (SHA-256) → 发送 ManifestS2C
客户端对比缓存 → 请求缺失/变更素材
服务端 32KB 分片下发 (AssetPartS2C)
客户端拼接写盘 → 发送 SyncDoneC2S → 打开角色面板
```

**关键 API**：

| 方法                                             | 说明       |
| ---------------------------------------------- | -------- |
| `ensureDefaults()`                             | 写入内嵌默认图标 |
| `sendManifest(player)`                         | 下发素材清单   |
| `sendPart(player, assetName, partIndex)`       | 下发素材分片   |
| `markPending(player)` / `clearPending(player)` | 同步状态管理   |

***

### 5.14 网络通道

**文件**: [RpChannels.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/network/RpChannels.java)

使用 Forge `SimpleChannel`，通道名 `ccnr_rp:main`，版本 1。

**注册的包类型**：

| 包方向       | 包类                        | 说明       |
| --------- | ------------------------- | -------- |
| C2S → S2C | `RequestCharacterListC2S` | 请求角色列表   |
| S2C → C2S | `CharacterListS2C`        | 角色列表响应   |
| C2S → S2C | `SelectCharacterC2S`      | 选择角色     |
| C2S → S2C | `DeployPositionC2S`       | 部署位置上报   |
| C2S → S2C | `KillDeployC2S`           | 重新部署     |
| S2C → C2S | `RecruitOfferS2C`         | 招募邀请     |
| C2S → S2C | `RecruitResponseC2S`      | 招募响应     |
| S2C → C2S | `AnimationPayloadS2C`     | 动画序列包    |
| S2C → C2S | `XpUpdateS2C`             | 经验更新     |
| S2C → C2S | `LevelUpS2C`              | 升级特效     |
| C2S → S2C | `ServerConfigSetC2S`      | 管理面板配置设置 |
| S2C → C2S | `AdminControlS2C`         | 管理控制     |
| S2C → C2S | `AssetManifestS2C`        | 素材清单     |
| S2C → C2S | `AssetPartS2C`            | 素材分片     |
| C2S → S2C | `AssetSyncDoneC2S`        | 素材同步完成   |
| S2C → C2S | `RulesStateS2C`           | 经验规则集同步  |
| S2C → C2S | `PlayerTagsS2C`           | 玩家标签同步   |

**关键 API**：

| 方法                       | 说明         |
| ------------------------ | ---------- |
| `register()`             | 注册所有包和处理器  |
| `sendTo(player, packet)` | 发送到指定玩家    |
| `sendToAll(packet)`      | 全服广播       |
| `hasChannel(connection)` | 检查客户端是否有通道 |

***

### 5.15 命令系统

**根命令**: `/rp`，注册于 `RpCommand.java`

| 子命令                   | 处理类                 | 说明                     |
| --------------------- | ------------------- | ---------------------- |
| `rp faction`          | `FactionCommand`    | 阵营管理（列表/信息/设置关系）       |
| `rp profession`       | `ProfessionCommand` | 职业管理（列表/信息/装备预设）       |
| `rp character`        | `CharacterCommand`  | 角色管理（列表/选择/部署）         |
| `rp state`            | `StateCommand`      | 状态管理（查看/设置）            |
| `rp xp` / `rp settle` | `XpCommand`         | 经验管理（查询/添加/结算）         |
| `rp level`            | `XpCommand`         | 等级查询                   |
| `rp event`            | `EventCommand`      | 事件管理（列表/触发/结束）         |
| `rp animation`        | `AnimationCommand`  | 动画管理（播放/列表）            |
| `rp spawn`            | `SpawnCommand`      | 刷新管理（触发波/列表）           |
| `rp db`               | `DbCommand`         | 数据库管理（状态/测试/迁移/导出/配置档） |
| `rp help`             | 内建                  | 帮助信息                   |

***

### 5.16 Corpse 联动

**文件**: [CorpseBridge.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/corpse/CorpseBridge.java)

与 Corpse 模组（`modid=corpse`）的可选集成，通过 `ModList` 探测。

**功能**：

* `registerHooks()` — 注册遗体钩子（死亡身份注入 + 名字牌）

* `clearCaptured()` — 清空未消费的死亡角色身份暂存

Corpse 为可选依赖（`mods.toml` 中 `mandatory=false`），缺失时走原生死亡降级。

***

### 5.17 客户端

#### 5.17.1 ClientAnimationPlayer

**文件**: [ClientAnimationPlayer.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/client/ClientAnimationPlayer.java)

客户端动画执行器，接收服务端 S2C payload，按 tick 执行：

* `TITLE` — 显示标题

* `FADE` — 淡入淡出

* `CAMERA` / `CAMS` — 摄像机控制

* `GROUP` — 子步骤组

#### 5.17.2 ClientAssetCache

**文件**: [ClientAssetCache.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/client/ClientAssetCache.java)

客户端素材缓存管理：

* 对比服务端清单与本地缓存

* 按需请求分片下载

* 超时跳过失败下载

* 全部完成时发送 `AssetSyncDoneC2S`

#### 5.17.3 ClientPacketHandlers

**文件**: [ClientPacketHandlers.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/client/ClientPacketHandlers.java)

客户端网络包处理入口，所有 S2C 包的客户端处理逻辑集中在此。

#### 5.17.4 ClientForgeEvents

**文件**: [ClientForgeEvents.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/client/ClientForgeEvents.java)

客户端 Forge 事件监听，负责 tick 调度 `ClientAssetCache.tick()`。

***

### 5.18 工具与权限

#### Permissions

**文件**: [Permissions.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/util/Permissions.java)

权限节点定义：

| 权限节点                      | 说明   |
| ------------------------- | ---- |
| `ccnr_rp.admin`           | 管理权限 |
| `ccnr_rp.admin.animation` | 动画管理 |

#### InventoryObserverMixin

**文件**: [InventoryObserverMixin.java](file:///c:/Users/Administrator/Downloads/CCNR-RP-main/CCNR-RP-main/src/main/java/com/ccnrcom/rp/mixins/InventoryObserverMixin.java)

Mixin 注入，用于观察玩家背包变化。

***

## 6. 关键数据流

### 6.1 玩家登录流程

```
PlayerLoggedInEvent
  ├→ maybeQueueFirstJoin()           // 首次入服自动部署入队
  ├→ 冷却检查 → DEAD→OBSERVING       // 状态归一化
  ├→ characters.sendList()            // 发送角色列表
  ├→ characters.broadcastPlayerTags() // 广播头顶标签
  ├→ AssetLibrary 素材同步            // 下发素材清单
  ├→ 死亡状态旁观者模式               // GameMode.SPECTATOR
  └→ experience.flushPending()        // 补发离线结算通知
```

### 6.2 死亡事件流程

```
玩家死亡 (Forge LivingDeathEvent)
  └→ StatusManager.onPlayerDeath()
       ├→ 击杀经验广播 (ExperienceService.onEvent)
       ├→ 死亡通知 (全服/好友)
       ├→ 状态迁移: ALIVE → DEAD
       ├→ 冷却设置
       ├→ 遗体生成 (CorpseBridge / 原生)
       ├→ 死亡点记录
       └→ 结算待处理 XP
```

### 6.3 事件触发流程

```
服务端 tick (EventManager.tick)
  ├→ PhaseClock.tick() → 阶段推进
  ├→ evaluateAll() → 触发器求值
  │    ├→ ON_PHASE_START/END → TriggerEvaluator
  │    ├→ ON_TIME → TriggerEvaluator
  │    ├→ PERIODIC → TriggerEvaluator
  │    └→ CONDITION → TriggerEvaluator
  └→ 命中 → startEvent()
       ├→ AnimationEngine.playHook("event_start")
       ├→ SpawnFramework.triggerWave(spawnWave)
       ├→ SequenceEngine.start(startSequence)
       └→ 事件状态: RUNNING
```

### 6.4 经验结算流程

```
经验事件触发 (ExperienceService.onEvent)
  ├→ 规则匹配 (condition 表达式)
  ├→ 数值计算 (value 表达式)
  ├→ 标题生成 (title 表达式)
  ├→ 加入待结算列表 (pendingXp)
  └→ ...
  
结算触发 (settle / settleAll)
  ├→ 求和 pendingXp
  ├→ 更新用户总 XP
  ├→ LevelCurve.level() → 等级判断
  ├→ 推送 HUD 动画 (XpUpdateS2C)
  ├→ 升级 → LevelUpS2C + 升级特效
  └→ 持久化用户数据
```

### 6.5 刷新波流程

```
triggerWave(waveId)
  ├→ 查找 Wave 定义
  ├→ 过滤候选玩家 (状态/冷却/在线/等级)
  ├→ WaveQuota.split() 名额分配
  ├→ 存活征召 → RecruitOfferS2C
  ├→ 观察者选岗 → 部署
  ├→ 执行波内嵌行为序列 (steps)
  └→ 招募超时 → 取消
```

***

## 7. 配置文件清单

| 路径                                     | 类型         | 说明          |
| -------------------------------------- | ---------- | ----------- |
| `serverconfig/ccnr_rp-server.toml`     | Forge TOML | 服务端调参（自动生成） |
| `config/db.properties`                 | Properties | 数据库连接配置     |
| `config/ccnr_rp/factions.json`         | JSON       | 阵营/职业定义     |
| `config/ccnr_rp/events.json`           | JSON       | 事件定义        |
| `config/ccnr_rp/phases.json`           | JSON       | 阶段定义        |
| `config/ccnr_rp/spawn_waves.json`      | JSON       | 刷新波定义       |
| `config/ccnr_rp/animations.json`       | JSON       | 动画序列定义      |
| `config/ccnr_rp/sequences.json`        | JSON       | 行为序列定义      |
| `config/ccnr_rp/experience_rules.json` | JSON       | 经验规则定义      |
| `config/ccnr_rp/settings.json`         | JSON       | 管理面板设置      |
| `world/ccnr_rp/characters.json`        | JSON       | 运行时角色数据     |
| `world/ccnr_rp/user_profiles.json`     | JSON       | 运行时用户档案     |
| `world/ccnr_rp/xp_ledger.json`         | JSON       | 经验账簿        |
| `world/ccnr_rp/pending_notices.json`   | JSON       | 待补发通知       |

***

## 8. 开发与构建

### 8.1 环境要求

* JDK 21（系统默认 Zulu 26 不符，需手动 export）

* Gradle 8.x（使用 wrapper）

* Forge MDK 1.20.1

### 8.2 常用命令

```bash
# 导出 JAVA_HOME
export JAVA_HOME=/path/to/jdk-21

# 设置 Gradle 共享缓存
export GRADLE_USER_HOME=/path/to/.gradle-home

# 完整构建（语法检查 + 风格检查）
./gradlew build

# 运行单元测试
./gradlew test -PrunTests

# 代码格式化（提交前必跑）
./gradlew spotlessApply

# 启动开发服务器
./gradlew runServer

# 启动客户端
./gradlew runClient
```

### 8.3 构建产出

`build/libs/ccnr_rp-*.jar` — 可部署的 Forge 模组文件。

### 8.4 开发纪律

* **先读后写**：动工前先读目标代码及相邻注册/事件/网络/配置/生命周期代码

* **服务端权威**：所有状态由服务端维护，客户端只发意图

* **线程边界**：独立线程只碰纯数据/不可变快照；网络/渲染必须回主线程

* **对称清理**：资源/线程/监听器对称创建释放

* **数据驱动**：优先 JSON 配置，配置开关必须真正改执行路径

* **纯逻辑可测**：无 MC 依赖的纯逻辑类可直接 JUnit 测试

***

## 9. 测试体系

### 9.1 测试门控

`build.gradle` 中 `onlyIf -PrunTests` 门控，普通 `build` 不执行测试，CI 需显式 `-PrunTests`。

### 9.2 测试分类

| 测试类                           | 覆盖内容                |
| ----------------------------- | ------------------- |
| `FactionGraphTest`            | 阵营关系图解析、多对多、组关系、优先级 |
| `FactionManagerSaveTest`      | 阵营保存回归测试            |
| `FactionProfessionsTest`      | 职业配置 upsert 测试      |
| `StatusMachineTest`           | 状态迁移、幂等、非法拒绝        |
| `SpawnModelsTest`             | 波配置解析、模式语义、名额分配     |
| `DeployLimitsTest`            | 部署限制规则解析与验证         |
| `ExperienceRuleTest`          | 经验规则校验、解析、JSON 往返   |
| `ExprTest`                    | 表达式引擎算术/函数/布尔/错误    |
| `LevelCurveTest`              | 等级曲线边界与单调性          |
| `XpChangeListTest`            | 经验变化列表合并与求和         |
| `ExperienceEventRegistryTest` | 内置事件与参数完整性          |
| `TriggerEvaluatorTest`        | 五种触发器类型判定           |
| `PhaseClockTest`              | 阶段时钟推进与边界           |
| `AnimationModelsTest`         | 动画序列解析与类型校验         |
| `ProfessionJsonTest`          | 职业 Loadout JSON 编解码 |
| `NbtCodecTest`                | NBT 编解码往返           |
| `MusicStoreTest`              | 音乐文件名校验             |
| `UserRepositoryTest`          | 用户数据 SQLite 读写      |
| `LangFileTest`                | 中英文语言包键一致性          |
| `ProjectMetadataTest`         | 工程元数据一致性            |

***

## 10. 依赖关系图

### 10.1 模块依赖

```
CCNRRPMod (入口)
  ├── Config (CCNRRPConfig, ManagerSettings)
  │     └── ConfigStore (DB/磁盘双后端)
  ├── Database
  │     ├── DbConfig → db.properties
  │     ├── DbSchema → DDL
  │     ├── SqlDialect (SQLite/MySQL)
  │     ├── UserRepository (→ users, user_pending_xp)
  │     ├── AssetRepository (→ assets)
  │     └── orm.SqlMapper (微 ORM)
  ├── FactionManager
  │     ├── FactionModels (领域模型)
  │     ├── FactionGraph (关系图引擎)
  │     └── FactionProfessions (职业配置)
  ├── CharacterService
  ├── UserService
  ├── StatusManager
  │     ├── StatusMachine (状态机)
  │     └── CharacterStatus (枚举)
  ├── CorpseBridge (可选)
  ├── ExperienceService
  │     ├── ExperienceModels (领域模型)
  │     ├── Expr (表达式引擎)
  │     ├── LevelCurve (等级曲线)
  │     └── PendingNoticeStore
  ├── SpawnFramework
  │     ├── SpawnModels (波定义)
  │     ├── DeployLimits (部署限制)
  │     └── DeployFlag (部署 flags)
  ├── AnimationEngine
  │     ├── AnimationModels (序列模型)
  │     └── AnimationHooks (钩子契约)
  ├── EventManager
  │     ├── EventModels (事件模型)
  │     ├── PhaseClock (阶段时钟)
  │     └── TriggerEvaluator (触发器求值器)
  ├── SequenceEngine
  ├── AssetLibrary
  └── Network (RpChannels, RpPackets)
        ├── ClientPacketHandlers
        ├── ClientAnimationPlayer
        └── ClientAssetCache
```

### 10.2 外部依赖

| 依赖                     | 类型 | 说明     |
| ---------------------- | -- | ------ |
| Minecraft Forge 1.20.1 | 必选 | 游戏平台   |
| Mixin 0.8.5            | 必选 | 代码注入框架 |
| SQLite JDBC            | 可选 | 内置数据库  |
| MySQL JDBC             | 可选 | 外部数据库  |
| Corpse Forge 1.20.1    | 可选 | 尸体模组联动 |

***

## 附录：版本阶段对照

| 阶段 | 功能          | 状态 |
| -- | ----------- | -- |
| P0 | 项目骨架、构建、数据库 | ✅  |
| P1 | 阵营系统        | ✅  |
| P2 | 角色/职业系统     | ✅  |
| P3 | 用户系统        | ✅  |
| P4 | 状态管理、死亡/冷却  | ✅  |
| P5 | 经验系统、表达式引擎  | ✅  |
| P6 | 事件系统、阶段时钟   | ✅  |
| P7 | 动画引擎        | ✅  |
| P8 | 刷新框架、征召波    | ✅  |
| P9 | 序列引擎、完整集成   | ✅  |

