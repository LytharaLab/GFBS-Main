/*
 * Copyright (c) 2026 CCNR
 * SPDX-License-Identifier: MIT
 */
package com.ccnrcom.rp.event;

import com.ccnrcom.rp.CCNRRPMod;
import com.ccnrcom.rp.animation.AnimationHooks;
import com.ccnrcom.rp.config.CCNRRPConfig;
import com.ccnrcom.rp.data.ConfigStore;
import com.ccnrcom.rp.event.EventModels.EventDefinition;
import com.ccnrcom.rp.event.EventModels.EventState;
import com.ccnrcom.rp.event.EventModels.GamePhase;
import com.ccnrcom.rp.event.EventModels.TriggerContext;
import com.ccnrcom.rp.network.RpChannels;
import com.ccnrcom.rp.network.RpPackets;
import com.ccnrcom.rp.status.CharacterStatus;
import com.ccnrcom.rp.util.JsonUtil;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 事件管理（P6）：阶段时钟推进 → 触发器求值 → 事件生命周期 SCHEDULED→RUNNING→SETTLED；
 * 结束钩子：动画（P7）/刷新波（P8 预留）/自动结算（P5）。
 */
public final class EventManager {
    private static final Logger LOGGER = LogManager.getLogger();

    private final MinecraftServer server;
    private PhaseClock clock;
    private final List<EventDefinition> events = new ArrayList<>();
    private long evalCounter = 0;
    private long startedAtMillis = System.currentTimeMillis();

    public EventManager(MinecraftServer server) {
        this.server = server;
        this.clock = new PhaseClock(loadPhases());
        loadEvents();
    }

    /** 热重载（管理器 CRUD 后调用）：重读 phases.json/events.json。 */
    public void reload() {
        events.clear();
        clock = new PhaseClock(loadPhases());
        loadEvents();
        LOGGER.info("[CCNR-RP] 事件/阶段已热重载");
        broadcastState();
    }

    /** 当前激活事件 id 列表（RUNNING）。 */
    public List<String> activeEventIds() {
        return events.stream()
                .filter(e -> e.state() == EventState.RUNNING)
                .map(EventDefinition::id)
                .toList();
    }

    /** 推送激活事件横幅（全服在线）。 */
    public void broadcastState() {
        JsonObject pay = new JsonObject();
        JsonArray a = new JsonArray();
        activeEventIds().forEach(id -> a.add(id));
        pay.add("events", a);
        for (ServerPlayer p : onlinePlayers()) {
            RpChannels.sendTo(p, new RpPackets.EventStateS2C(pay.toString()));
        }
    }

    /** 清空当前事件（/rp event clear）：全部 RUNNING → SETTLED → 重置为 SCHEDULED 并广播横幅。 */
    public List<String> clearAll() {
        List<String> out = new ArrayList<>();
        for (int i = 0; i < events.size(); i++) {
            EventDefinition def = events.get(i);
            if (def.state() == EventState.RUNNING) {
                events.set(i, def.withState(EventState.SETTLED));
                out.add(def.id());
            }
        }
        resetEvents();
        broadcastState();
        return out;
    }

    public PhaseClock clock() {
        return clock;
    }

    public List<EventDefinition> events() {
        return List.copyOf(events);
    }

    private JsonObject loadOrDefaults(String configKey, String resource) {
        JsonObject root = ConfigStore.load(configKey).orElseGet(JsonObject::new);
        if (root.size() == 0) {
            JsonObject d = JsonUtil.readResource(resource).orElseGet(JsonObject::new);
            ConfigStore.save(configKey, d);
            return d;
        }
        return root;
    }

    private List<GamePhase> loadPhases() {
        return EventModels.parsePhases(loadOrDefaults("phases.json", "/assets/ccnr_rp/defaults/phases.json"));
    }

    private void loadEvents() {
        JsonObject root = loadOrDefaults("events.json", "/assets/ccnr_rp/defaults/events.json");
        for (String e : EventModels.parseEvents(root)) {
            LOGGER.error("[CCNR-RP] events.json: {}", e);
        }
        if (root.has("events")) {
            for (com.google.gson.JsonElement el : root.getAsJsonArray("events")) {
                EventModels.parseEvent(el.getAsJsonObject()).ifPresent(events::add);
            }
        }
    }

    /** 重启事件状态（阶段迁移后事件重新进入 SCHEDULED）。 */
    public void resetEvents() {
        for (int i = 0; i < events.size(); i++) {
            if (events.get(i).state() != EventState.RUNNING) {
                events.set(i, events.get(i).withState(EventState.SCHEDULED));
            }
        }
    }

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        int interval = Math.max(1, CCNRRPConfig.EVENT_EVAL_INTERVAL_TICKS.get());
        if (++evalCounter < interval) {
            return;
        }
        evalCounter = 0;
        // 阶段时钟按节流周期推进（修复重复 tick 导致阶段时长偏短、迁移被丢弃、phase 触发器不触发）
        PhaseClock.Transition tr = clock.tick(interval);
        evaluateAll(tr);
        autoEndRunnings();
    }

    /** 阶段开始 → 执行内嵌行为序列。 */
    private void runPhaseSteps(PhaseClock.Transition tr) {
        if (CCNRRPMod.sequenceEngine == null || tr == null || !tr.changed() || tr.started() == null) {
            return;
        }
        for (GamePhase p : clock.phases()) {
            if (p.id().equals(tr.started()) && p.steps() != null && !p.steps().isEmpty()) {
                CCNRRPMod.sequenceEngine.runSteps("phase/" + p.id(), p.steps(), java.util.Map.of("phase", p.id()));
                return;
            }
        }
    }

    private void evaluateAll(PhaseClock.Transition tr) {
        runPhaseSteps(tr);
        long gameDay = server.getLevel(net.minecraft.world.level.Level.OVERWORLD) == null
                ? 0L
                : server.getLevel(net.minecraft.world.level.Level.OVERWORLD).getDayTime() / 24000L;
        TriggerContext ctx = new TriggerContext(
                clock.phaseId(),
                tr.ended(),
                clock.ticksInPhase(),
                gameDay,
                server.getLevel(net.minecraft.world.level.Level.OVERWORLD) == null
                        ? 0L
                        : server.getLevel(net.minecraft.world.level.Level.OVERWORLD)
                                        .getDayTime()
                                % 24000L,
                (System.currentTimeMillis() - startedAtMillis) / 1000L,
                deadCount(),
                aliveCount(),
                scoreboard(),
                tr.changed() && tr.started() != null,
                tr.changed() && tr.ended() != null);
        for (int i = 0; i < events.size(); i++) {
            EventDefinition def = events.get(i);
            if (!def.enabled() || def.state() != EventState.SCHEDULED) {
                continue;
            }
            if (def.triggers().stream().anyMatch(t -> TriggerEvaluator.evaluate(t, ctx))) {
                startEvent(i);
            }
        }
    }

    private void startEvent(int index) {
        EventDefinition def = events.get(index);
        events.set(index, def.withState(EventState.RUNNING));
        noteStart(def);
        LOGGER.info("[CCNR-RP] 事件开始: {} ", def.id());
        List<ServerPlayer> targets = onlinePlayers();
        targets.forEach(p -> RpChannels.sendTo(p, new RpPackets.ErrorS2C("ccnr_rp.event.started", def.id())));
        AnimationHooks.eventStart(def.id(), targets);
        broadcastState();
        // P8：刷新波钩子（若已实现）
        if (!def.spawnWave().isBlank() && CCNRRPMod.spawnFramework != null) {
            CCNRRPMod.spawnFramework.triggerWave(def.spawnWave());
        }
        // 行为序列（内嵌步骤序列：等待/命令/刷新波/强制抽取等；兼容旧 startSequence 引用）
        if (CCNRRPMod.sequenceEngine != null) {
            if (def.steps() != null && !def.steps().isEmpty()) {
                CCNRRPMod.sequenceEngine.runSteps(
                        "event/" + def.id(),
                        def.steps(),
                        java.util.Map.of("event", def.id(), "phase", clock.phaseId()));
            } else if (!def.startSequence().isBlank()) {
                CCNRRPMod.sequenceEngine.run(
                        def.startSequence(), java.util.Map.of("event", def.id(), "phase", clock.phaseId()));
            }
        }
    }

    private void autoEndRunnings() {
        for (int i = 0; i < events.size(); i++) {
            EventDefinition def = events.get(i);
            if (def.state() == EventState.RUNNING && def.durationSeconds() > 0 && defStartedAt(def) > 0) {
                // 简化：按事件 id 记录启动时间的内存表在 P6 用 startTime 字段存储——维护于本类
                long elapsed = System.currentTimeMillis() - runStart.getOrDefault(def.id(), System.currentTimeMillis());
                if (elapsed >= def.durationSeconds() * 1000L) {
                    endEvent(i);
                }
            }
        }
    }

    private final Map<String, Long> runStart = new HashMap<>();

    private void noteStart(EventDefinition def) {
        runStart.put(def.id(), System.currentTimeMillis());
    }

    private long defStartedAt(EventDefinition def) {
        return runStart.getOrDefault(def.id(), 0L);
    }

    /** 强制启动（命令；仅 SCHEDULED 且 enabled）。 */
    public boolean triggerEvent(String eventId) {
        for (int i = 0; i < events.size(); i++) {
            EventDefinition def = events.get(i);
            if (def.id().equals(eventId) && def.enabled() && def.state() == EventState.SCHEDULED) {
                startEvent(i);
                return true;
            }
        }
        return false;
    }

    public boolean setEnabled(String eventId, boolean on) {
        for (int i = 0; i < events.size(); i++) {
            if (events.get(i).id().equals(eventId)) {
                EventDefinition d = events.get(i);
                EventDefinition nd = new EventDefinition(
                        d.id(),
                        on,
                        d.triggers(),
                        d.tasks(),
                        d.startAnimation(),
                        d.spawnWave(),
                        d.startSequence(),
                        d.notifyTitleKey(),
                        d.durationSeconds(),
                        on ? EventState.SCHEDULED : EventState.SETTLED,
                        d.steps());
                events.set(i, nd);
                return true;
            }
        }
        return false;
    }

    public boolean setPhase(String phaseId) {
        for (int i = 0; i < clock.phases().size(); i++) {
            if (clock.phases().get(i).id().equals(phaseId)) {
                clock.set(i);
                return true;
            }
        }
        return false;
    }

    /** 管理端手动触发事件（C2S，管理员权限校验）。 */
    public static void onAdminTrigger(ServerPlayer player, String eventId) {
        if (player == null || CCNRRPMod.eventManager == null) {
            return;
        }
        if (!com.ccnrcom.rp.util.Permissions.canAdmin(player, com.ccnrcom.rp.util.Permissions.ADMIN_EVENT)) {
            RpChannels.sendTo(player, new RpPackets.ErrorS2C("ccnr_rp.command.no_permission"));
            return;
        }
        boolean ok = CCNRRPMod.eventManager.triggerEvent(eventId);
        RpChannels.sendTo(
                player, new RpPackets.ErrorS2C(ok ? "ccnr_rp.event.triggered" : "ccnr_rp.event.not_runnable", eventId));
    }

    /** 手动结束事件（命令）。 */
    public boolean endEvent(String eventId) {
        for (int i = 0; i < events.size(); i++) {
            if (events.get(i).id().equals(eventId) && events.get(i).state() == EventState.RUNNING) {
                endEvent(i);
                return true;
            }
        }
        return false;
    }

    private void endEvent(int index) {
        EventDefinition def = events.get(index);
        events.set(index, def.withState(EventState.SETTLED));
        LOGGER.info("[CCNR-RP] 事件结束: {} ", def.id());
        List<ServerPlayer> targets = onlinePlayers();
        targets.forEach(p -> RpChannels.sendTo(p, new RpPackets.ErrorS2C("ccnr_rp.event.ended", def.id())));
        broadcastState();
    }

    /** 游戏结束：game_end 动画钩子（经验不自动结算；结算仅死亡退场与 /rp settle 触发）。 */
    public void gameOver() {
        AnimationHooks.gameEnd(onlinePlayers());
    }

    private int deadCount() {
        if (CCNRRPMod.users == null) {
            return 0;
        }
        return (int) CCNRRPMod.users.uuids().stream()
                .filter(uuid -> CCNRRPMod.users.status(uuid) == CharacterStatus.DEAD)
                .count();
    }

    private int aliveCount() {
        if (CCNRRPMod.users == null) {
            return 0;
        }
        return (int) CCNRRPMod.users.uuids().stream()
                .filter(uuid -> CCNRRPMod.users.status(uuid) == CharacterStatus.ALIVE)
                .count();
    }

    private Map<String, Integer> scoreboard() {
        return Map.of();
    }

    private List<ServerPlayer> onlinePlayers() {
        return new ArrayList<>(server.getPlayerList().getPlayers());
    }
}
