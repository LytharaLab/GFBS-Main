/*
 * Copyright (c) 2026 CCNR
 * SPDX-License-Identifier: MIT
 */
package com.ccnrcom.rp.client;

import net.minecraft.client.gui.GuiGraphics;

/**
 * CCNR-RP 界面主题 v5——"Apple 深色模式"：
 * 黑灰底 / 深色卡片 / 蓝主题色 / 干净圆角 / 层次分明。
 * 参考 Apple 深色设计语言：dark gray 背景，白字，蓝 accent。
 */
public final class RpTheme {
    // ---- 几何 ----
    public static final float RADIUS_SMALL = 6;
    public static final float RADIUS_MEDIUM = 8;
    public static final float RADIUS_LARGE = 12;
    public static final float RADIUS_CARD = 14;
    /** 屏幕按钮圆角别名（CCNR-RP 界面）。 */
    public static final float RADIUS_BUTTON = RADIUS_MEDIUM;
    /** 屏幕输入框圆角别名。 */
    public static final float RADIUS_INPUT = RADIUS_SMALL;

    public static final int PAD = 8;
    public static final int PAD_LARGE = 16;
    /** 屏幕卡片内边距。 */
    public static final int PADDING_CARD = 12;
    /** 屏幕元素间距。 */
    public static final int GAP = 8;
    /** 屏幕大间距。 */
    public static final int GAP_LARGE = 16;
    /** 屏幕基准宽度。 */
    public static final int SCREEN_WIDTH = 320;
    /** 屏幕基准高度。 */
    public static final int SCREEN_HEIGHT = 240;

    // ---- 背景色（半透明深色系，玩家可透过 UI 看到游戏画面）----
    /** 主背景色（半透明深黑灰 #1C1C1E，约 67% 不透明） */
    public static final int BACKGROUND = 0xAA1C1C1E;
    /** 卡片背景色（半透明深灰 #2C2C2E，约 80% 不透明） */
    public static final int CARD_BG = 0xCC2C2C2E;
    /** 二级卡片/面板背景色（半透明稍亮深灰 #3A3A3C） */
    public static final int CARD_BG_ALT = 0xCC3A3A3C;
    /** 列表隔行背景色（半透明深灰 #333335） */
    public static final int CARD_BG_EVEN = 0xCC333335;
    /** 屏幕二级面板别名（同 CARD_BG_ALT）。 */
    public static final int CARD_BG_SECONDARY = CARD_BG_ALT;
    /** 页脚/底部栏背景色（半透明深灰 #252527） */
    public static final int FOOTER_BG = 0xCC252527;
    /** 悬停/选中背景（半透明深蓝 #1A2A44） */
    public static final int HOVER_BG = 0xCC1A2A44;
    /** 选中高亮背景（半透明深蓝 #1E3A5F） */
    public static final int SELECTED_BG = 0xCC1E3A5F;
    /** 不可用/禁用背景（半透明深灰 #2A2A2C） */
    public static final int DISABLED_BG = 0xCC2A2A2C;
    /** 半透明遮罩 */
    public static final int OVERLAY = 0x60000000;

    // ---- 文字色（白 → 浅灰，清晰可读）----
    /** 主文字色（白 #FFFFFF） */
    public static final int TEXT_PRIMARY = 0xFFFFFFFF;
    /** 二级文字色（浅灰 #AEAEB2） */
    public static final int TEXT_SECONDARY = 0xFFAEAEB2;
    /** 三级/提示文字色（中灰 #636366） */
    public static final int TEXT_DIM = 0xFF636366;
    /** 屏幕三级文字别名（同 TEXT_DIM）。 */
    public static final int TEXT_TERTIARY = TEXT_DIM;
    /** 白色文字 */
    public static final int TEXT_WHITE = 0xFFFFFFFF;

    // ---- 主色调：蓝色（Apple 深色模式蓝 #0A84FF）----
    /** 主题蓝（按钮/链接 #0A84FF） */
    public static final int BLUE = 0xFF0A84FF;
    /** 主题蓝 - 按下态（深蓝 #0066D6） */
    public static final int BLUE_DIM = 0xFF0066D6;
    /** 主题蓝 - 悬停态（中蓝 #0071E3） */
    public static final int BLUE_HOVER = 0xFF0071E3;
    /** 主题蓝 - 淡色背景（深蓝 #0A2C44） */
    public static final int BLUE_BG = 0xFF0A2C44;
    /** 屏幕主题蓝别名。 */
    public static final int ACCENT_BLUE = BLUE;
    /** 屏幕按下态别名。 */
    public static final int ACCENT_BLUE_PRESSED = BLUE_DIM;
    /** 屏幕悬停态别名。 */
    public static final int ACCENT_BLUE_HOVER = BLUE_HOVER;

    // ---- 语义色 ----
    /** 危险/删除色（红 #FF453A） */
    public static final int RED = 0xFFFF453A;
    /** 危险深色（深红 #D62B20） */
    public static final int RED_DIM = 0xFFD62B20;
    /** 危险浅背景（深红 #3A1C1A） */
    public static final int RED_BG = 0xFF3A1C1A;
    /** 屏幕危险色别名。 */
    public static final int DANGER_RED = RED;
    /** 成功/在线色（绿 #30D158） */
    public static final int GREEN = 0xFF30D158;
    /** 屏幕成功色别名。 */
    public static final int SUCCESS_GREEN = GREEN;
    /** 警告色（橙 #FF9F0A） */
    public static final int ORANGE = 0xFFFF9F0A;
    /** 屏幕警告色别名。 */
    public static final int WARNING_ORANGE = ORANGE;
    /** 复活冷却剩余提示色（淡橙）。 */
    public static final int COOLDOWN = 0xFFFF9E9E;

    // ---- 边框与分割线（半透明）----
    /** 边框色（半透明深灰 #48484A） */
    public static final int BORDER = 0x9948484A;
    /** 亮边框色（悬停态，半透明 #5A5A5E） */
    public static final int BORDER_BRIGHT = 0x995A5A5E;
    /** 分割线色（半透明深灰 #38383A） */
    public static final int DIVIDER = 0x8838383A;

    // ---- 状态标签色 ----
    public static final int STATUS_ALIVE = GREEN;
    public static final int STATUS_DEAD = RED;
    public static final int STATUS_OBSERVING = 0xFF8E8E93;

    private RpTheme() {}

    /** rgb + alpha 混合。 */
    public static int alphaBlend(int rgb, int alpha) {
        return (alpha << 24) | (rgb & 0xFFFFFF);
    }

    public static int statusColor(String status) {
        return switch (status) {
            case "alive" -> STATUS_ALIVE;
            case "dead" -> STATUS_DEAD;
            default -> STATUS_OBSERVING;
        };
    }

    /** 机构等级 → 徽章环色：1 金 / 2 蓝 / 其他 主题蓝。 */
    public static int tierColor(int tier) {
        return switch (Math.max(1, Math.min(3, tier))) {
            case 1 -> ORANGE;
            case 2 -> BLUE;
            default -> BLUE;
        };
    }

    // ── 绘图构件 ──

    /** Apple 风格卡片：半透明深色底 + 半透明边框 + 圆角。 */
    public static void card(GuiGraphics g, int x1, int y1, int x2, int y2, float radius, int bg) {
        RpRoundRect.outlined(g, x1, y1, x2, y2, radius, BORDER, bg);
    }

    /** Apple 风格终端面板（主容器）。 */
    public static void terminalPanel(GuiGraphics g, int x1, int y1, int x2, int y2, float radius) {
        RpRoundRect.outlined(g, x1, y1, x2, y2, radius, BORDER, CARD_BG);
    }

    /** Apple 风格选中高亮：深蓝背景 + 左侧蓝色高亮线。 */
    public static void selectedBar(GuiGraphics g, int x1, int y1, int x2, int y2, float radius) {
        RpRoundRect.fill(g, x1, y1, x2, y2, radius, SELECTED_BG);
        RpRoundRect.fill(g, x1, y1, x1 + 3, y2, radius, BLUE);
        g.fill(x1 + 4, y2 - 2, x2 - 4, y2 - 1, BLUE);
    }

    /** 标签风格："[ 标签 ]"。 */
    public static String tag(String s) {
        return "[ " + s + " ]";
    }

    /** 按像素宽度截断文本：超出 maxW 时以省略号结尾，防止文字冲出 UI 边界。 */
    public static String clip(net.minecraft.client.gui.Font font, String text, int maxW) {
        if (text == null) {
            return "";
        }
        if (maxW <= 0 || font.width(text) <= maxW) {
            return text;
        }
        return font.plainSubstrByWidth(text, Math.max(1, maxW - font.width("…"))) + "…";
    }
}
