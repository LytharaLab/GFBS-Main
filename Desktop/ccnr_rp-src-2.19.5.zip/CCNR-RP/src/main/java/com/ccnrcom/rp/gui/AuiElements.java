/*
 * Copyright (c) 2026 CCNR
 * SPDX-License-Identifier: MIT
 */
package com.ccnrcom.rp.gui;

import com.sighs.apricityui.registry.ApricityUIRegistry;

/** AUI 元素注册入口：扫描本模组包下的 {@code @ElementRegister} 自定义元素。 */
public final class AuiElements {

    private AuiElements() {}

    /** 模组初始化时调用：注册扫描包并执行注册（服务端/客户端均安全，内部判空）。 */
    public static void register() {
        try {
            ApricityUIRegistry.scanPackage("com.ccnrcom.rp.gui.element");
            ApricityUIRegistry.register();
        } catch (Throwable t) {
            // AUI 未安装时降级：不注册自定义元素，界面逻辑不受影响
            org.apache.logging.log4j.LogManager.getLogger().debug("[CCNR-RP] AUI 元素注册跳过: {}", t.toString());
        }
    }
}
