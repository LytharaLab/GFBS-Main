/*
 * Copyright (c) 2026 CCNR
 * SPDX-License-Identifier: MIT
 */
package com.ccnrcom.rp.command;

import com.ccnrcom.rp.gui.AuiScreens;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.tree.LiteralCommandNode;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/**
 * /rp gui 子命令：使用 AUI（ApricityUI）打开客户端界面。
 *
 * <p>用法：
 * <ul>
 *   <li>/rp gui character  - 打开角色选择界面
 *   <li>/rp gui faction    - 打开阵营信息界面
 *   <li>/rp gui status     - 打开玩家状态界面
 *   <li>/rp gui settings   - 打开管理面板
 * </ul>
 */
public class GuiCommand {

    public static void register(LiteralCommandNode<CommandSourceStack> rpNode) {
        LiteralArgumentBuilder<CommandSourceStack> builder = Commands.literal("gui")
                .requires(source -> source.getEntity() instanceof ServerPlayer)
                .then(Commands.argument("screen", StringArgumentType.word())
                        .suggests((ctx, builder2) -> {
                            builder2.suggest("character", Component.literal("角色选择界面"));
                            builder2.suggest("faction", Component.literal("阵营信息界面"));
                            builder2.suggest("status", Component.literal("玩家状态界面"));
                            builder2.suggest("settings", Component.literal("管理面板"));
                            return builder2.buildFuture();
                        })
                        .executes(GuiCommand::execute))
                .executes(ctx -> {
                    ctx.getSource().sendSuccess(() -> Component.literal("§6§l/rp gui §e- CCNR-RP GUI 界面§r"), false);
                    ctx.getSource().sendSuccess(() -> Component.literal("  §7/rp gui character  §8- 角色选择"), false);
                    ctx.getSource().sendSuccess(() -> Component.literal("  §7/rp gui faction    §8- 阵营信息"), false);
                    ctx.getSource().sendSuccess(() -> Component.literal("  §7/rp gui status     §8- 玩家状态"), false);
                    ctx.getSource().sendSuccess(() -> Component.literal("  §7/rp gui settings   §8- 管理面板"), false);
                    return Command.SINGLE_SUCCESS;
                });
        rpNode.addChild(builder.build());
    }

    private static int execute(CommandContext<CommandSourceStack> ctx) {
        String screen = StringArgumentType.getString(ctx, "screen");
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player;

        try {
            player = source.getPlayerOrException();
        } catch (Exception e) {
            source.sendFailure(Component.literal("该命令只能由玩家执行"));
            return 0;
        }

        String path =
                switch (screen.toLowerCase()) {
                    case "character", "char", "角色" -> AuiScreens.CHARACTER;
                    case "faction", "factions", "阵营" -> AuiScreens.FACTION;
                    case "status", "state", "状态" -> AuiScreens.STATUS;
                    case "settings", "setting", "admin", "设置", "管理" -> AuiScreens.SETTINGS;
                    default -> {
                        source.sendFailure(Component.literal("未知界面类型: " + screen));
                        yield null;
                    }
                };

        if (path == null) {
            return 0;
        }
        if (AuiScreens.open(player, path)) {
            source.sendSuccess(() -> Component.literal("§7正在打开界面..."), false);
        } else {
            source.sendFailure(Component.literal("§cAUI（ApricityUI）未安装，无法打开界面。请安装 ApricityUI 模组。"));
            source.sendSuccess(() -> Component.literal("§7提示：可使用 /rp character/faction 等命令查看信息"), false);
        }
        return Command.SINGLE_SUCCESS;
    }
}
