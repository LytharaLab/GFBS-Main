/*
 * Copyright (c) 2026 CCNR
 * SPDX-License-Identifier: MIT
 */
package com.ccnrcom.rp.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

/**
 * Apple 风格按钮：扁平化 + 圆角 + 灰色主题。
 * primary=蓝底白字（主操作）/ secondary=浅灰底深灰字（次级）/ danger=红底白字（危险操作）。
 */
public final class RpButton extends Button {
    private final int fill;
    private final int fillHover;
    private final int border;
    private final int borderHover;
    private final int fg;
    private final int fgHover;

    private RpButton(
            int x,
            int y,
            int w,
            int h,
            Component label,
            OnPress onPress,
            int fill,
            int fillHover,
            int border,
            int borderHover,
            int fg,
            int fgHover) {
        super(x, y, w, h, label, onPress, DEFAULT_NARRATION);
        this.fill = fill;
        this.fillHover = fillHover;
        this.border = border;
        this.borderHover = borderHover;
        this.fg = fg;
        this.fgHover = fgHover;
    }

    /** 主操作：蓝底白字 + 圆角。 */
    public static RpButton primary(int x, int y, int w, int h, Component label, OnPress onPress) {
        return new RpButton(
                x,
                y,
                w,
                h,
                label,
                onPress,
                RpTheme.BLUE,
                RpTheme.BLUE_HOVER,
                RpTheme.BLUE,
                RpTheme.BLUE_DIM,
                RpTheme.TEXT_WHITE,
                RpTheme.TEXT_WHITE);
    }

    /** 次级：浅灰底深灰字 + 灰边框。 */
    public static RpButton secondary(int x, int y, int w, int h, Component label, OnPress onPress) {
        return new RpButton(
                x,
                y,
                w,
                h,
                label,
                onPress,
                RpTheme.CARD_BG,
                RpTheme.CARD_BG_ALT,
                RpTheme.BORDER,
                RpTheme.TEXT_SECONDARY,
                RpTheme.TEXT_PRIMARY,
                RpTheme.TEXT_PRIMARY);
    }

    /** 危险：红底白字。 */
    public static RpButton danger(int x, int y, int w, int h, Component label, OnPress onPress) {
        return new RpButton(
                x,
                y,
                w,
                h,
                label,
                onPress,
                RpTheme.RED,
                RpTheme.RED_DIM,
                RpTheme.RED,
                RpTheme.RED_DIM,
                RpTheme.TEXT_WHITE,
                RpTheme.TEXT_WHITE);
    }

    /** 弹窗内静态绘制按钮（非 widget，交给父屏手动命中）。 */
    public static void draw(GuiGraphics g, int x1, int y1, int x2, int y2, String label, int border, boolean primary) {
        RpRoundRect.outlined(g, x1, y1, x2, y2, RpTheme.RADIUS_SMALL, border, primary ? RpTheme.BLUE : RpTheme.CARD_BG);
        Font f2 = Minecraft.getInstance().font;
        int tw = f2.width(label);
        g.drawString(
                f2,
                label,
                x1 + (x2 - x1 - tw) / 2,
                y1 + (y2 - y1 - 8) / 2,
                primary ? RpTheme.TEXT_WHITE : RpTheme.TEXT_PRIMARY,
                true);
    }

    @Override
    public void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        int f = isHovered() ? fillHover : fill;
        int b = isHovered() ? borderHover : border;
        RpRoundRect.outlined(g, getX(), getY(), getX() + getWidth(), getY() + getHeight(), RpTheme.RADIUS_MEDIUM, b, f);
        // 悬停时轻微加深
        if (isHovered()) {
            RpRoundRect.fill(
                    g,
                    getX() + 2,
                    getY() + 2,
                    getX() + getWidth() - 2,
                    getY() + getHeight() - 2,
                    RpTheme.RADIUS_SMALL,
                    RpTheme.alphaBlend(b, 0x12));
        }
        int color = active ? (isHovered() ? fgHover : fg) : 0xFF8E8E93;
        Font f2 = Minecraft.getInstance().font;
        int tw = f2.width(getMessage());
        g.drawString(f2, getMessage(), getX() + (getWidth() - tw) / 2, getY() + (getHeight() - 8) / 2, color, true);
    }
}
