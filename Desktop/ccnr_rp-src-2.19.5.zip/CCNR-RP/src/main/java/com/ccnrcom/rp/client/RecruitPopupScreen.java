/*
 * Copyright (c) 2026 CCNR
 * SPDX-License-Identifier: MIT
 */
package com.ccnrcom.rp.client;

import com.ccnrcom.rp.network.RpChannels;
import com.ccnrcom.rp.network.RpPackets;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * 招募请求窗 v3——Apple 风格右侧面板。
 * 圆角深色卡片 + 清晰的招募信息层级 + 蓝/红主题按钮。
 */
public class RecruitPopupScreen extends Screen {
    private static RecruitPopupScreen open;

    private int px1, py1, px2, py2;
    private static final int PANEL_W = 380;
    private static final int CARD_RADIUS = 10;
    private static final int CARD_GAP = 4;

    public RecruitPopupScreen() {
        super(Component.translatable("ccnr_rp.spawn.recruit.title"));
    }

    public static void refreshIfOpen() {
        if (open != null) {
            open.rebuild();
        }
    }

    private List<RecruitOverlayHud.OfferEntry> entries() {
        return RecruitOverlayHud.OFFERS.stream().filter(e -> !e.accepted()).toList();
    }

    private void rebuild() {
        clearWidgets();
        int x = px1 + 12;
        int y = py1 + 42;
        for (RecruitOverlayHud.OfferEntry o : entries()) {
            // 接受按钮（蓝底白字）
            addRenderableWidget(RpButton.primary(
                    x + 192, y + 26, 72, 24, Component.translatable("ccnr_rp.spawn.recruit.accept"), b -> {
                        RpChannels.sendToServer(new RpPackets.RecruitAnswerC2S(o.offerId(), true));
                        RecruitOverlayHud.markAccepted(o.offerId());
                        rebuild();
                    }));
            // 拒绝按钮（灰底深灰字）
            addRenderableWidget(RpButton.secondary(
                    x + 268, y + 26, 72, 24, Component.translatable("ccnr_rp.spawn.recruit.decline"), b -> {
                        RpChannels.sendToServer(new RpPackets.RecruitAnswerC2S(o.offerId(), false));
                        RecruitOverlayHud.remove(o.offerId());
                        rebuild();
                    }));
            y += 80 + CARD_GAP;
        }
    }

    @Override
    protected void init() {
        open = this;
        px1 = this.width - PANEL_W - 12;
        py1 = (this.height - 280) / 2;
        px2 = this.width - 12;
        py2 = (this.height + 280) / 2;
        rebuild();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        // 半透明背景遮罩
        g.fill(0, 0, width, height, 0x60000000);
        // 主面板
        RpRoundRect.outlined(g, px1, py1, px2, py2, 14f, RpTheme.BORDER, RpTheme.CARD_BG);
        // 标题栏
        g.drawString(font, title, px1 + 16, py1 + 14, RpTheme.BLUE, true);
        // 浅灰分隔线
        g.fill(px1 + 16, py1 + 32, px2 - 16, py1 + 33, RpTheme.DIVIDER);
        // 招募卡片列表
        int y = py1 + 42;
        for (RecruitOverlayHud.OfferEntry o : entries()) {
            int cardH = 74;
            int kc = kindColor(o.kind());
            // 卡片背景
            RpRoundRect.outlined(g, px1 + 10, y, px2 - 10, y + cardH, CARD_RADIUS, RpTheme.BORDER, RpTheme.CARD_BG_ALT);
            // 左侧类型色条（细线）
            g.fill(px1 + 12, y + 4, px1 + 14, y + cardH - 4, kc);
            // 人物立绘
            CharacterPreview.renderPortrait(
                    g,
                    px1 + 36,
                    y + 30,
                    19,
                    o.charId(),
                    o.charName(),
                    ClientCharacterState.professionLoadout(o.professionId()));
            // 职业名称（截断防止冲出卡片/按钮区，右侧按钮从 px1+192 开始）
            String profName = ClientCharacterState.professionName(o.professionId());
            String facName = ClientCharacterState.factionNameOf(o.professionId());
            int textW = Math.max(40, (px1 + 190) - (px1 + 64) - 6);
            g.drawString(font, RpTheme.clip(font, profName, textW), px1 + 64, y + 8, RpTheme.TEXT_PRIMARY, true);
            // 阵营 · 类型标签
            g.drawString(
                    font,
                    RpTheme.clip(
                            font,
                            (facName.isEmpty() ? "" : facName + " · ")
                                    + Component.translatable(kindKey(o.kind())).getString(),
                            textW),
                    px1 + 64,
                    y + 22,
                    kc,
                    true);
            // 描述文字
            g.drawString(
                    font,
                    RpTheme.clip(
                            font, Component.translatable(kindDescKey(o.kind())).getString(), textW),
                    px1 + 64,
                    y + 36,
                    RpTheme.TEXT_SECONDARY,
                    true);
            // 项目简历
            String profile = ClientCharacterState.professionProfile(o.professionId());
            if (!profile.isBlank()) {
                int rw = (px2 - 12) - (px1 + 64);
                List<String> lines = wrapText(profile, Math.max(40, rw));
                int ry = y + 48;
                g.enableScissor(px1 + 64, ry, px2 - 12, y + cardH - 4);
                for (int i = 0; i < Math.min(lines.size(), 2); i++) {
                    g.drawString(font, lines.get(i), px1 + 64, ry, RpTheme.TEXT_DIM);
                    ry += 10;
                }
                g.disableScissor();
            }
            y += 80 + CARD_GAP;
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    private static int kindColor(String kind) {
        return switch (kind == null ? "" : kind) {
            case "conscript" -> RpTheme.RED;
            case "typed" -> RpTheme.ORANGE;
            case "pick" -> RpTheme.BLUE;
            default -> RpTheme.TEXT_SECONDARY;
        };
    }

    private static String kindKey(String kind) {
        return switch (kind == null ? "" : kind) {
            case "conscript" -> "ccnr_rp.spawn.recruit.kind_conscript";
            case "typed" -> "ccnr_rp.spawn.recruit.kind_typed";
            case "pick" -> "ccnr_rp.spawn.recruit.kind_pick";
            default -> "ccnr_rp.spawn.recruit.kind_wave";
        };
    }

    private static String kindDescKey(String kind) {
        return switch (kind == null ? "" : kind) {
            case "conscript" -> "ccnr_rp.spawn.recruit.desc_conscript";
            case "typed" -> "ccnr_rp.spawn.recruit.desc_typed";
            case "pick" -> "ccnr_rp.spawn.recruit.desc_pick";
            default -> "ccnr_rp.spawn.recruit.desc_wave";
        };
    }

    @Override
    public void tick() {
        if (entries().isEmpty()) {
            onClose();
        }
    }

    private List<String> wrapText(String text, int maxW) {
        List<String> out = new ArrayList<>();
        if (text == null || text.isBlank()) {
            out.add("");
            return out;
        }
        StringBuilder cur = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '\n' || font.width(cur.toString() + c) > maxW) {
                out.add(cur.toString());
                cur.setLength(0);
                if (c == '\n') continue;
            }
            cur.append(c);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    @Override
    public void onClose() {
        open = null;
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
