/*
 * Copyright (c) 2026 CCNR
 * SPDX-License-Identifier: MIT
 */
package com.ccnrcom.rp.client;

import com.ccnrcom.rp.network.RpChannels;
import com.ccnrcom.rp.network.RpPackets;
import com.ccnrcom.rp.profession.ItemStackCodec;
import com.ccnrcom.rp.profession.ProfessionJson;
import com.ccnrcom.rp.status.CharacterStatus;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

/**
 * K 面板 v2——「职位选择」机密终端（角色库已删除，改为按职位部署）。
 * 三栏：左＝机构过滤导航｜中＝职位列表（需求等级绿/红）｜右＝职位详情 + 部署按钮（未达等级置红）。
 * 部署＝选择职位，等级门控由服务端校验；客户端未达等级时部署按钮变红/禁用。
 */
public class CharacterManagementScreen extends Screen {

    private static CharacterManagementScreen open;

    private final List<JsonObject> professions = new ArrayList<>();
    private final List<JsonObject> factionMeta = new ArrayList<>();
    private final List<int[]> navBounds = new ArrayList<>();
    private final List<int[]> rowBounds = new ArrayList<>();

    private String selectedId = "";
    private String filterFaction = "";
    private int scroll = 0;
    private int navScroll = 0;
    private String notice = "";
    private long noticeUntil = 0;
    /** 重新部署确认弹窗（暂时隐藏，不触发）：非空=正在确认该职位；如需恢复，在场点部署时置 confirmDeployId。 */
    private String confirmDeployId = "";

    // 布局几何
    private int px1, py1, px2, py2;
    private int hdrY1, hdrY2;
    private int bodyY1, bodyY2;
    private int nlX1, nlX2;
    private int mlX1, mlX2;
    private int rlX1, rlX2;
    private int deployY;
    private int mgrX1, mgrY1, mgrX2, mgrY2;

    public CharacterManagementScreen() {
        super(Component.translatable("ccnr_rp.gui.character.title"));
    }

    public static void refreshIfOpen() {
        if (open != null && net.minecraft.client.Minecraft.getInstance() != null) {
            open.reloadData();
            open.rebuild();
        }
    }

    public static void closeIfOpen() {
        if (open != null) {
            open.onClose();
        }
    }

    @Override
    protected void init() {
        open = this;
        reloadData();
        px1 = 16;
        py1 = 16;
        px2 = width - 16;
        py2 = height - 16;
        hdrY1 = py1 + 4;
        hdrY2 = hdrY1 + 20;
        bodyY1 = hdrY2 + 26;
        bodyY2 = py2 - 8;
        int innerW = px2 - px1 - 16;
        int nlw = Math.max(84, Math.min(200, innerW * 22 / 100));
        int mlw = Math.max(150, Math.min(300, innerW * 30 / 100));
        nlX1 = px1 + 8;
        nlX2 = nlX1 + nlw;
        mlX1 = nlX2 + 8;
        mlX2 = mlX1 + mlw;
        rlX1 = mlX2 + 8;
        rlX2 = px2 - 8;
        deployY = bodyY2 - 70;
        String mgr = Component.translatable("ccnr_rp.gui.character.manage").getString();
        mgrX2 = px2 - 40;
        mgrX1 = mgrX2 - font.width(mgr) - 8;
        mgrY1 = hdrY1 - 1;
        mgrY2 = hdrY1 + 17;
        rebuild();
    }

    private void reloadData() {
        professions.clear();
        professions.addAll(ClientCharacterState.professions());
        factionMeta.clear();
        factionMeta.addAll(ClientCharacterState.factions());
        if (filterFaction.isEmpty()
                || factionMeta.stream().noneMatch(f -> f.get("id").getAsString().equals(filterFaction))) {
            filterFaction = "";
        }
        if (selectedId.isEmpty()
                || professions.stream().noneMatch(p -> str(p, "id").equals(selectedId))) {
            selectedId = "";
        }
    }

    private void rebuild() {
        clearWidgets();
        navBounds.clear();
        rowBounds.clear();
        int navH = 22;
        int navGap = 4;
        int y = bodyY1 + 2;
        navBounds.add(new int[] {nlX1, y, nlX2, y + navH, -1});
        y += navH + navGap;
        for (int i = 0; i < factionMeta.size(); i++) {
            navBounds.add(new int[] {nlX1, y, nlX2, y + navH, i});
            y += navH + navGap;
        }
        List<JsonObject> visible = filtered();
        int rowH = 44;
        int rowGap = 4;
        int listH = bodyY2 - bodyY1 - 2;
        int maxVisible = Math.max(1, (listH + rowGap) / (rowH + rowGap));
        int offset = Math.min(scroll, Math.max(0, visible.size() - maxVisible));
        for (int i = 0; i < visible.size() && i < maxVisible; i++) {
            int ry = bodyY1 + 2 + i * (rowH + rowGap);
            rowBounds.add(new int[] {mlX1, ry, mlX2, ry + rowH});
        }
        buildRight();
    }

    private void buildRight() {
        clearWidgets();
        JsonObject p = findProfession(selectedId);
        int x = rlX1;
        int w = rlX2 - rlX1;
        if (p != null) {
            int ay = deployY;
            boolean met = userLevel() >= unlockLevel(p);
            CharacterStatus st = ClientCharacterState.userStatus();
            boolean observing = st == CharacterStatus.OBSERVING;
            boolean alive = st == CharacterStatus.ALIVE;
            boolean onCd = ClientCharacterState.userCooldownUntil() > System.currentTimeMillis();
            // 部署人数限制（全局性，客户端预览；服务端 deploy 统一入口仍会强校验）：
            // 重新部署（在场换岗）时自己已占旧职业/阵营位，目标职业/阵营在职数按「不含自己」计算
            boolean selfAlive = alive;
            boolean selfInProf = selfAlive && selectedId.equals(ClientCharacterState.userProfessionId());
            boolean selfInFac = selfAlive && str(p, "factionId").equals(ClientCharacterState.userFactionId());
            int profOccupied = ClientCharacterState.professionOccupied(selectedId) - (selfInProf ? 1 : 0);
            int facOccupied = ClientCharacterState.factionOccupied(str(p, "factionId")) - (selfInFac ? 1 : 0);
            int profLimit = ClientCharacterState.professionLimit(selectedId);
            int facLimit = ClientCharacterState.factionLimit(str(p, "factionId"));
            boolean profFull = profLimit >= 0 && profOccupied >= profLimit;
            boolean facFull = facLimit >= 0 && facOccupied >= facLimit;
            boolean canDeploy = met && (observing || alive) && !onCd && !profFull && !facFull;
            RpButton deploy =
                    RpButton.primary(x, ay, w, 22, Component.translatable("ccnr_rp.gui.character.deploy"), b -> {
                        if (ClientCharacterState.userStatus() == CharacterStatus.ALIVE) {
                            // 在场：重新部署（不处死/不留遗体/不结算死亡经验，服务端直接换装部署）
                            // 二次确认暂时隐藏（无处决后果，直接执行；恢复确认框可置 confirmDeployId）
                            RpChannels.sendToServer(new RpPackets.KillDeployC2S(selectedId));
                        } else {
                            RpChannels.sendToServer(new RpPackets.DeployPositionC2S(selectedId));
                        }
                        notice("");
                    });
            deploy.active = canDeploy;
            if (!met) {
                // 等级未达标：按钮置红并提示需要等级
                deploy.setMessage(Component.translatable("ccnr_rp.gui.character.need_level", unlockLevel(p)));
            } else if (profFull || facFull) {
                // 空位不足：禁用并提示限制（优先职业上限，其次阵营上限）
                if (profFull) {
                    deploy.setMessage(
                            Component.translatable("ccnr_rp.spawn.limit.profession_full", str(p, "name"), profLimit));
                } else {
                    deploy.setMessage(Component.translatable(
                            "ccnr_rp.spawn.limit.faction_full", factionName(p, factionMeta), facLimit));
                }
                deploy.active = false;
            } else if (!observing && !alive) {
                // 等级达标但当前状态不可部署（阴间等）：禁用（不误标为等级问题）
                deploy.setMessage(Component.translatable("ccnr_rp.gui.character.deploy"));
                deploy.active = false;
            } else if (alive) {
                // 在场可部署：按钮提示重新部署
                deploy.setMessage(Component.translatable("ccnr_rp.gui.character.deploy_kill"));
            }
            addRenderableWidget(deploy);
        }
    }

    private List<JsonObject> filtered() {
        if (filterFaction.isEmpty()) {
            return professions;
        }
        return professions.stream()
                .filter(p -> str(p, "factionId").equals(filterFaction))
                .toList();
    }

    private JsonObject findProfession(String id) {
        for (JsonObject p : professions) {
            if (str(p, "id").equals(id)) {
                return p;
            }
        }
        return null;
    }

    private JsonObject factionMeta(String id) {
        for (JsonObject f : factionMeta) {
            if (str(f, "id").equals(id)) {
                return f;
            }
        }
        return null;
    }

    private int userLevel() {
        return ClientCharacterState.userLevel();
    }

    private int unlockLevel(JsonObject p) {
        try {
            return p.has("unlockLevel") ? Math.max(0, p.get("unlockLevel").getAsInt()) : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * 职业是否无可用部署余额：与部署按钮同条件——职业或阵营维度在职数（在场换岗按不含本人算）≥ 上限，或上限 0=禁止。
     * 职业维度上限 professionLimit() 已含 GLOBAL 兜底（未配置专属规则的职业按 GLOBAL 计），与部署按钮/服务端校验一致。
     */
    private boolean profNoBalance(JsonObject p) {
        String profId = str(p, "id");
        String facId = str(p, "factionId");
        boolean selfAlive = ClientCharacterState.userStatus() == CharacterStatus.ALIVE;
        boolean selfInProf = selfAlive && profId.equals(ClientCharacterState.userProfessionId());
        boolean selfInFac = selfAlive && facId.equals(ClientCharacterState.userFactionId());
        int profOcc = ClientCharacterState.professionOccupied(profId) - (selfInProf ? 1 : 0);
        int facOcc = ClientCharacterState.factionOccupied(facId) - (selfInFac ? 1 : 0);
        int profLim = ClientCharacterState.professionLimit(profId);
        int facLim = ClientCharacterState.factionLimit(facId);
        return (profLim >= 0 && profOcc >= profLim) || (facLim >= 0 && facOcc >= facLim);
    }

    /** 阵营是否无可用职业复活：该阵营下所有职业均无可用余额（无职业也视为不可用）。 */
    private boolean facNoAvailable(JsonObject fac) {
        for (JsonObject p : professions) {
            if (str(p, "factionId").equals(str(fac, "id")) && !profNoBalance(p)) {
                return false;
            }
        }
        return true;
    }

    private static String factionName(JsonObject p, List<JsonObject> metas) {
        String fid = str(p, "factionId");
        for (JsonObject f : metas) {
            if (str(f, "id").equals(fid)) {
                return str(f, "name");
            }
        }
        return fid;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (!confirmDeployId.isEmpty()) {
            // 重新部署确认弹窗（暂时隐藏）：确认/取消按钮，弹窗期间吞掉其余点击
            int[][] rects = confirmButtonRects();
            if (mx >= rects[0][0] && mx <= rects[0][2] && my >= rects[0][1] && my <= rects[0][3]) {
                String id = confirmDeployId;
                confirmDeployId = "";
                RpChannels.sendToServer(new RpPackets.KillDeployC2S(id));
                notice("");
            } else if (mx >= rects[1][0] && mx <= rects[1][2] && my >= rects[1][1] && my <= rects[1][3]) {
                confirmDeployId = "";
            }
            return true;
        }
        if (super.mouseClicked(mx, my, button)) {
            return true;
        }
        // 标题栏 ✕：点击关闭（悬停只高亮，不关闭）
        if (mx >= px2 - 28 && mx <= px2 - 10 && my >= hdrY1 - 1 && my <= hdrY1 + 17) {
            onClose();
            return true;
        }
        // 管理按钮
        if (mx >= mgrX1 && mx <= mgrX2 && my >= mgrY1 && my <= mgrY2) {
            if (ClientCharacterState.isAdmin()) {
                net.minecraft.client.Minecraft.getInstance().setScreen(new RpAdminScreen());
            } else {
                notice("ccnr_rp.command.no_permission");
            }
            return true;
        }
        // 滚动条点击（分类=1，职位列表=2）
        int navNs = RpScrollbar.clickV(
                (int) mx, (int) my, nlX2 - 7, nlX2 - 2, bodyY1, bodyY2, navBounds.size(), navVisible(), navScroll, 1);
        if (navNs >= 0) {
            navScroll = (int) Math.max(0, Math.min(navNs, Math.max(0, navBounds.size() - navVisible())));
            return true;
        }
        int listNs = RpScrollbar.clickV(
                (int) mx,
                (int) my,
                mlX2 - 7,
                mlX2 - 2,
                bodyY1,
                bodyY2,
                filtered().size(),
                maxVisibleRows(),
                scroll,
                2);
        if (listNs >= 0) {
            scroll = (int) Math.max(0, Math.min(listNs, Math.max(0, filtered().size() - maxVisibleRows())));
            rebuild();
            return true;
        }
        int navEnd = Math.min(navBounds.size(), navScroll + navVisible());
        for (int i = navScroll; i < navEnd; i++) {
            int[] b = navRect(i);
            if (mx >= b[0] && mx <= b[2] && my >= b[1] && my <= b[3]) {
                filterFaction = b[4] < 0 ? "" : str(factionMeta.get(b[4]), "id");
                scroll = 0;
                rebuild();
                return true;
            }
        }
        int offset = offsetOfRows();
        for (int i = 0; i < rowBounds.size(); i++) {
            int[] b = rowBounds.get(i);
            if (mx >= b[0] && mx <= b[2] && my >= b[1] && my <= b[3]) {
                List<JsonObject> visible = filtered();
                if (offset + i < visible.size()) {
                    selectedId = str(visible.get(offset + i), "id");
                }
                rebuild();
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int b, double dx, double dy) {
        int ns = RpScrollbar.dragV((int) my);
        if (ns >= 0) {
            if (RpScrollbar.dragId() == 1) {
                navScroll = (int) Math.max(0, Math.min(ns, Math.max(0, navBounds.size() - navVisible())));
            } else {
                scroll = (int) Math.max(0, Math.min(ns, Math.max(0, filtered().size() - maxVisibleRows())));
                rebuild();
            }
            return true;
        }
        return super.mouseDragged(mx, my, b, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int b) {
        RpScrollbar.endDrag();
        return super.mouseReleased(mx, my, b);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        if (mx >= nlX1 && mx <= nlX2 && my >= bodyY1 - 4 && my <= bodyY2) {
            navScroll =
                    (int) Math.max(0, Math.min(navScroll - delta / 10, Math.max(0, navBounds.size() - navVisible())));
            return true;
        }
        if (mx >= mlX1 && mx <= mlX2 && my >= bodyY1 - 4 && my <= bodyY2) {
            scroll = (int) Math.max(0, scroll - delta / 10);
            rebuild();
        }
        return true;
    }

    private int maxVisibleRows() {
        int rowH = 44;
        int gap = 4;
        int listH = bodyY2 - bodyY1 - 2;
        return Math.max(1, (listH + gap) / (rowH + gap));
    }

    private int offsetOfRows() {
        return Math.min(scroll, Math.max(0, filtered().size() - maxVisibleRows()));
    }

    private void notice(String key) {
        if (key == null || key.isBlank()) {
            notice = "";
            return;
        }
        notice = Component.translatable(key).getString();
        noticeUntil = System.currentTimeMillis() + 2600;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        // Apple 灰色背景
        g.fill(0, 0, width, height, RpTheme.BACKGROUND);
        RpTheme.terminalPanel(g, px1, py1, px2, py2, RpTheme.RADIUS_CARD);
        // 主面板底部阴影线（Apple 风格浅投影）
        g.fill(px1 + 4, py2 + 1, px2 - 4, py2 + 2, 0x12000000);
        renderHeader(g, mx, my);
        renderColHeaders(g);
        renderNav(g, mx, my);
        renderList(g, mx, my);
        renderDetail(g, mx, my);
        renderNotice(g);
        super.render(g, mx, my, partial);
        if (!confirmDeployId.isEmpty()) {
            renderKillConfirm(g, mx, my);
        }
    }

    private void renderHeader(GuiGraphics g, int mx, int my) {
        int y = hdrY1 + 5;
        RpIcons.badge(g, px1 + 17, hdrY1 + 10, 8, "hex", 1, false);
        String head = Component.translatable("ccnr_rp.gui.character.db_header")
                .getString()
                .toUpperCase(Locale.ROOT);
        g.drawString(font, head, px1 + 30, y, RpTheme.BLUE, true);
        String statusLabel =
                switch (ClientCharacterState.userStatus()) {
                    case ALIVE -> Component.translatable("ccnr_rp.gui.character.status.alive")
                            .getString();
                    case DEAD -> Component.translatable("ccnr_rp.gui.character.status.dead")
                            .getString();
                    default -> Component.translatable("ccnr_rp.gui.character.status.observing")
                            .getString();
                };
        String lvl = "Lv " + userLevel() + "  " + statusLabel;
        g.drawString(font, lvl, px1 + 30 + font.width(head) + 40, y, RpTheme.TEXT_SECONDARY, true);
        // Apple 风格分割线（浅灰）
        g.fill(px1 + 8, hdrY2 - 1, px2 - 8, hdrY2, RpTheme.DIVIDER);
        // 管理按钮
        boolean mgrHover = my >= mgrY1 && my <= mgrY2 && mx >= mgrX1 && mx <= mgrX2;
        if (mgrHover) {
            RpRoundRect.fill(g, mgrX1 - 2, mgrY1 - 1, mgrX2 + 2, mgrY2 + 1, RpTheme.RADIUS_SMALL, RpTheme.HOVER_BG);
        }
        g.drawString(
                font,
                Component.translatable("ccnr_rp.gui.character.manage").getString(),
                mgrX1 + 4,
                hdrY1 + 4,
                ClientCharacterState.isAdmin() ? RpTheme.BLUE : RpTheme.TEXT_DIM,
                true);
        // 关闭按钮（✕）
        boolean hover = my >= hdrY1 - 1 && my <= hdrY1 + 17 && mx >= px2 - 28 && mx <= px2 - 10;
        if (hover) {
            RpRoundRect.fill(g, px2 - 30, hdrY1 - 2, px2 - 8, hdrY1 + 18, RpTheme.RADIUS_SMALL, RpTheme.RED_BG);
        }
        g.drawString(font, "✕", px2 - 20, hdrY1 + 4, hover ? RpTheme.RED : RpTheme.TEXT_SECONDARY, true);
    }

    private void renderColHeaders(GuiGraphics g) {
        int y = hdrY2 + 8;
        g.drawString(
                font,
                RpTheme.tag(Component.translatable("ccnr_rp.gui.character.nav").getString()),
                nlX1,
                y,
                RpTheme.TEXT_DIM);
        g.drawString(
                font,
                RpTheme.tag(Component.translatable("ccnr_rp.gui.character.position_list")
                                .getString()) + " (" + filtered().size() + ")",
                mlX1,
                y,
                RpTheme.TEXT_DIM);
        g.drawString(
                font,
                RpTheme.tag(Component.translatable("ccnr_rp.gui.character.detail_header")
                        .getString()),
                rlX1,
                y,
                RpTheme.TEXT_DIM);
        g.fill(nlX1, y + 12, rlX2, y + 13, RpTheme.DIVIDER);
    }

    private int[] navRect(int i) {
        int navH = 22;
        int gap = 4;
        int y = bodyY1 + 2 + (i - navScroll) * (navH + gap);
        int facIdx = navBounds.get(i)[4]; // 存储的阵营索引（-1=全部），非位置下标
        return new int[] {nlX1, y, nlX2, y + navH, facIdx};
    }

    private void renderNav(GuiGraphics g, int mx, int my) {
        int end = Math.min(navBounds.size(), navScroll + navVisible());
        for (int i = navScroll; i < end; i++) {
            int[] b = navRect(i);
            JsonObject fac = b[4] < 0 ? null : factionMeta.get(b[4]);
            boolean sel =
                    !filterFaction.isEmpty() && fac != null && str(fac, "id").equals(filterFaction);
            boolean hover = mx >= b[0] && mx <= b[2] && my >= b[1] && my <= b[3];
            boolean noAvail = fac != null && facNoAvailable(fac);
            if (sel) {
                RpTheme.selectedBar(g, b[0], b[1], b[2], b[3], RpTheme.RADIUS_MEDIUM);
            } else {
                int bg = noAvail ? RpTheme.RED_BG : (hover ? RpTheme.HOVER_BG : RpTheme.CARD_BG);
                int bd = noAvail ? RpTheme.RED : (hover ? RpTheme.TEXT_SECONDARY : RpTheme.BORDER);
                RpRoundRect.outlined(g, b[0], b[1], b[2], b[3], RpTheme.RADIUS_MEDIUM, bd, bg);
            }
            if (fac == null) {
                RpIcons.badge(g, b[0] + 12, b[1] + 11, 8, "target", 2, sel);
                g.drawString(
                        font,
                        Component.translatable("ccnr_rp.gui.character.filter.all")
                                .getString(),
                        b[0] + 25,
                        b[1] + 7,
                        sel ? RpTheme.TEXT_WHITE : RpTheme.TEXT_PRIMARY,
                        true);
            } else {
                RpIcons.factionBadge(g, b[0] + 12, b[1] + 11, 8, fac, sel);
                String name = str(fac, "name");
                int maxW = b[2] - b[0] - 28;
                if (font.width(name) > maxW) {
                    name = font.plainSubstrByWidth(name, maxW - 1) + "…";
                }
                g.drawString(
                        font,
                        name,
                        b[0] + 25,
                        b[1] + 7,
                        sel ? RpTheme.TEXT_WHITE : (noAvail ? RpTheme.RED : RpTheme.TEXT_PRIMARY),
                        true);
            }
        }
    }

    private void renderList(GuiGraphics g, int mx, int my) {
        RpRoundRect.outlined(
                g, mlX1 - 3, bodyY1 - 2, mlX2 + 3, bodyY2, RpTheme.RADIUS_LARGE, RpTheme.BORDER, RpTheme.CARD_BG);
        List<JsonObject> visible = filtered();
        int offset = offsetOfRows();
        for (int i = 0; i < rowBounds.size(); i++) {
            int[] b = rowBounds.get(i);
            int idx = offset + i;
            if (idx >= visible.size()) {
                break;
            }
            JsonObject p = visible.get(idx);
            boolean sel = str(p, "id").equals(selectedId);
            boolean hover = mx >= b[0] && mx <= b[2] && my >= b[1] && my <= b[3];
            boolean noBal = profNoBalance(p);
            if (sel) {
                RpTheme.selectedBar(g, b[0], b[1], b[2], b[3], RpTheme.RADIUS_MEDIUM);
            } else {
                int bg = noBal
                        ? RpTheme.RED_BG
                        : (hover ? RpTheme.HOVER_BG : (i % 2 == 0 ? RpTheme.CARD_BG : RpTheme.CARD_BG_ALT));
                int bd = noBal ? RpTheme.RED : (hover ? RpTheme.TEXT_SECONDARY : RpTheme.BORDER);
                RpRoundRect.outlined(g, b[0], b[1], b[2], b[3], RpTheme.RADIUS_MEDIUM, bd, bg);
            }
            JsonObject fac = factionMeta(str(p, "factionId"));
            RpIcons.factionBadge(g, b[0] + 14, b[1] + 14, 7, fac, false);
            // 右侧预留 Lv 标签 + 在职标签空间（约 100px），防止文字冲出行边界
            int textW = Math.max(20, b[2] - b[0] - 34 - 104);
            g.drawString(
                    font,
                    RpTheme.clip(font, str(p, "name"), textW),
                    b[0] + 34,
                    b[1] + 6,
                    sel ? RpTheme.TEXT_WHITE : (noBal ? RpTheme.RED : RpTheme.TEXT_PRIMARY),
                    true);
            g.drawString(
                    font,
                    RpTheme.clip(font, factionName(p, factionMeta), textW),
                    b[0] + 34,
                    b[1] + 20,
                    sel ? RpTheme.TEXT_WHITE : RpTheme.TEXT_SECONDARY);
            g.drawString(
                    font,
                    RpTheme.clip(font, str(p, "id"), Math.max(20, b[2] - b[0] - 34 - 12)),
                    b[0] + 34,
                    b[1] + 32,
                    sel ? RpTheme.TEXT_WHITE : RpTheme.TEXT_DIM);
            boolean met = userLevel() >= unlockLevel(p);
            String tag = "Lv " + unlockLevel(p);
            int tagW = font.width(tag) + 8;
            int tx2 = b[2] - 7;
            int color = met ? RpTheme.STATUS_ALIVE : RpTheme.RED;
            RpRoundRect.fill(
                    g,
                    tx2 - tagW,
                    b[1] + 6,
                    tx2,
                    b[1] + 18,
                    RpTheme.RADIUS_SMALL,
                    RpTheme.alphaBlend(color, met ? 0x66 : 0xFF));
            g.drawString(font, tag, tx2 - tagW + 4, b[1] + 8, met ? color : RpTheme.TEXT_WHITE, true);
            // 在职/上限小标签
            int lim = ClientCharacterState.professionLimit(str(p, "id"));
            if (lim >= 0) {
                int occ = ClientCharacterState.professionOccupied(str(p, "id"));
                String occTag = occ + "/" + lim;
                boolean full = occ >= lim;
                int oTagW = font.width(occTag) + 8;
                int ox2 = tx2 - tagW - 8;
                int oCol = full ? RpTheme.RED : RpTheme.STATUS_ALIVE;
                RpRoundRect.fill(
                        g,
                        ox2 - oTagW,
                        b[1] + 6,
                        ox2,
                        b[1] + 18,
                        RpTheme.RADIUS_SMALL,
                        RpTheme.alphaBlend(oCol, full ? 0xFF : 0x66));
                g.drawString(font, occTag, ox2 - oTagW + 4, b[1] + 8, full ? RpTheme.TEXT_WHITE : oCol, true);
            }
        }
        // 滚动条
        RpScrollbar.draw(g, mlX2 - 7, bodyY1, bodyY2, visible.size(), maxVisibleRows(), offsetOfRows());
        RpScrollbar.draw(g, nlX2 - 7, bodyY1, bodyY2, navBounds.size(), navVisible(), navScroll);
    }

    private int navVisible() {
        int navH = 22;
        int gap = 4;
        int listH = bodyY2 - bodyY1 - 2;
        return Math.max(1, (listH + gap) / (navH + gap));
    }

    private void renderDetail(GuiGraphics g, int mx, int my) {
        JsonObject p = findProfession(selectedId);
        int x = rlX1;
        int w = rlX2 - rlX1;
        int y = bodyY1;
        RpTheme.card(g, x, y, x + w, y + 44, RpTheme.RADIUS_LARGE, RpTheme.CARD_BG);
        if (p == null) {
            g.drawString(font, "— 选择一个职位 —", x + 10, y + 18, RpTheme.TEXT_DIM, true);
            g.drawString(font, "点选职位后可按部署", x + 10, y + 30, RpTheme.TEXT_DIM);
            return;
        }
        // 详情区可用文字宽度
        int textW = Math.max(20, w - 16);
        g.drawString(font, RpTheme.clip(font, str(p, "name"), textW), x + 8, y + 5, RpTheme.BLUE, true);
        String facName = factionName(p, factionMeta);
        String nameIdLine = "ID " + str(p, "id") + "  /  " + facName;
        g.drawString(font, RpTheme.clip(font, nameIdLine, textW), x + 8, y + 17, RpTheme.TEXT_DIM);
        boolean met = userLevel() >= unlockLevel(p);
        String req = "需求等级：Lv " + unlockLevel(p) + "（当前 Lv " + userLevel() + "）";
        g.drawString(font, RpTheme.clip(font, req, textW), x + 8, y + 24, met ? RpTheme.STATUS_ALIVE : RpTheme.RED);
        // 部署限制
        String profId = str(p, "id");
        String facId = str(p, "factionId");
        boolean selfAlive = ClientCharacterState.userStatus() == CharacterStatus.ALIVE;
        boolean selfInProf = selfAlive && profId.equals(ClientCharacterState.userProfessionId());
        boolean selfInFac = selfAlive && facId.equals(ClientCharacterState.userFactionId());
        int profLimit = ClientCharacterState.professionLimit(profId);
        int facLimit = ClientCharacterState.factionLimit(facId);
        int profOcc = ClientCharacterState.professionOccupied(profId) - (selfInProf ? 1 : 0);
        int facOcc = ClientCharacterState.factionOccupied(facId) - (selfInFac ? 1 : 0);
        StringBuilder lim = new StringBuilder("在职 ");
        if (profLimit >= 0) {
            lim.append(profOcc).append("/").append(profLimit).append(" 职业");
        } else {
            lim.append(profOcc).append("（职业不限）");
        }
        if (facLimit >= 0) {
            lim.append("  ·  阵营 ").append(facOcc).append("/").append(facLimit);
        }
        boolean profFull = profLimit >= 0 && profOcc >= profLimit;
        boolean facFull = facLimit >= 0 && facOcc >= facLimit;
        g.drawString(
                font,
                RpTheme.clip(font, lim.toString(), textW),
                x + 8,
                y + 36,
                (profFull || facFull) ? RpTheme.RED : RpTheme.STATUS_ALIVE);
        g.drawString(
                font,
                Component.translatable("ccnr_rp.gui.character.preview").getString(),
                x + 8,
                y + 48,
                RpTheme.TEXT_DIM,
                true);
        JsonObject loadout = loadoutOf(p);
        int contentTop = bodyY1 + 50;
        // 项目简历
        String profile = str(p, "profile");
        List<String> resumeLines = profile.isBlank() ? List.of() : wrapText(profile, w - 16);
        int maxFit = Math.max(1, (deployY - 12 - contentTop - 40) / 10);
        int resumeLineCount = Math.min(resumeLines.size(), Math.min(MAX_PROFILE_LINES, maxFit));
        int resumeH = resumeLineCount == 0 ? 0 : 15 + resumeLineCount * 10;
        int contentBottom = deployY - 12 - resumeH;
        int modelW = Math.max(88, w * 38 / 100);
        // 背景阵营徽章
        JsonObject facMeta = factionMeta(str(p, "factionId"));
        if (facMeta != null) {
            g.enableScissor(x, contentTop, x + w, contentBottom);
            String fIcon = facMeta.has("icon") && !facMeta.get("icon").isJsonNull()
                    ? facMeta.get("icon").getAsString()
                    : "hex";
            int fTier = facMeta.has("tier") ? facMeta.get("tier").getAsInt() : 2;
            int badgeCx = x + modelW + (w - modelW) * 3 / 4;
            int badgeCy = contentBottom - 26;
            int badgeR = Math.max(22, Math.min(40, (contentBottom - contentTop) / 4));
            com.ccnrcom.rp.client.RpIcons.bigBadge(g, badgeCx, badgeCy, badgeR, fIcon, fTier, 36);
            g.disableScissor();
        }
        // 3D 人物立绘
        g.enableScissor(x, contentTop, x + modelW, contentBottom);
        JsonObject ch = new JsonObject();
        ch.addProperty("id", "pos-" + selectedId);
        ch.addProperty("name", str(p, "name"));
        int modelH = contentBottom - contentTop;
        int scale = Math.max(12, Math.min(36, Math.min(modelH / 3 - 6, modelW / 3)));
        int cy = contentTop + modelH / 2 + 4;
        renderHoloBase(g, x + modelW / 2, contentTop, contentBottom, cy, scale);
        CharacterPreview.render(g, x + modelW / 2, cy, scale, ch, loadout);
        g.disableScissor();
        // 装备预览
        renderEquipList(g, x + modelW + 8, x + w - 8, contentTop, contentBottom, loadout, mx, my);
        // 项目简历
        if (resumeLineCount > 0) {
            renderProfileResume(g, x, w, contentBottom, deployY, resumeLines, resumeLineCount);
        }
    }

    /** 项目简历展示区最多行数（超长裁剪；显示区域受限时自动减少行数）。 */
    private static final int MAX_PROFILE_LINES = 4;

    /** 在装备预览之下、部署按钮之上渲染项目简历：分隔线 + 标签 + 折行文本（裁剪到展示区）。 */
    private void renderProfileResume(
            GuiGraphics g, int x, int w, int top, int buttonTop, List<String> lines, int lineCount) {
        int bottom = buttonTop - 8;
        g.fill(x + 2, top + 1, x + w - 2, top + 2, RpTheme.DIVIDER);
        g.drawString(
                font,
                Component.translatable("ccnr_rp.gui.character.profile").getString(),
                x + 2,
                top + 6,
                RpTheme.TEXT_DIM,
                true);
        g.enableScissor(x, top, x + w, bottom);
        int ly = top + 17;
        for (int i = 0; i < lineCount; i++) {
            g.drawString(font, lines.get(i), x + 2, ly, RpTheme.TEXT_SECONDARY);
            ly += 10;
        }
        g.disableScissor();
    }

    private static JsonObject loadoutOf(JsonObject p) {
        if (p == null || !p.has("loadout") || !p.get("loadout").isJsonObject()) {
            return null;
        }
        return p.getAsJsonObject("loadout");
    }

    /**
     * A档：全息投影底座（纯绘制，不改模型渲染）。人物背后一条青光柱，脚下透视地格 + 发光底座圆环，
     * 让立绘看起来像悬浮的全息投影。所有调用方为客户端主线程渲染，无每帧分配。
     */
    private static void renderHoloBase(GuiGraphics g, int cx, int top, int bottom, int cy, int scale) {
        int baseY = Math.min(bottom - 6, cy + scale);
        int beam = RpTheme.alphaBlend(RpTheme.BLUE, 0x4D);
        // 1) 纵向投影光柱
        if (top < baseY) {
            int bw = Math.max(6, scale / 2);
            g.fillGradient(cx - bw, top, cx + bw, baseY, RpTheme.alphaBlend(RpTheme.BLUE, 0), beam);
        }
        // 2) 底部透视地格
        int gx1 = cx - Math.max(20, scale * 3 / 2);
        int gx2 = cx + Math.max(20, scale * 3 / 2);
        for (int i = 1; i <= 4; i++) {
            int yy = baseY - (i * i) * 3;
            if (yy < top + 4) {
                break;
            }
            g.fill(gx1, yy, gx2, yy + 1, RpTheme.alphaBlend(RpTheme.BLUE, 90 - i * 16));
        }
        // 3) 发光底座
        int baseR = Math.max(8, Math.min(18, scale));
        com.ccnrcom.rp.client.RpIcons.ring(
                g, cx, baseY, baseR, RpTheme.alphaBlend(RpTheme.BLUE, 0x8C), RpTheme.CARD_BG);
        com.ccnrcom.rp.client.RpIcons.circle(
                g, cx, baseY, Math.max(2, baseR / 3), RpTheme.alphaBlend(RpTheme.BLUE, 0x5A));
    }

    private void renderEquipList(
            GuiGraphics g, int ex, int er, int top, int bottom, JsonObject loadout, int mx, int my) {
        String[] labels = {
            Component.translatable("ccnr_rp.gui.character.equip.head").getString(),
            Component.translatable("ccnr_rp.gui.character.equip.chest").getString(),
            Component.translatable("ccnr_rp.gui.character.equip.legs").getString(),
            Component.translatable("ccnr_rp.gui.character.equip.boots").getString(),
            Component.translatable("ccnr_rp.gui.character.equip.weapon").getString()
        };
        ItemStack[] stacks = {
            armorStack(loadout, 39),
            armorStack(loadout, 38),
            armorStack(loadout, 37),
            armorStack(loadout, 36),
            weaponStack(loadout)
        };
        int availH = bottom - top - 8;
        if (availH < 10) {
            return;
        }
        int rowH = Math.max(18, Math.min(26, availH / labels.length));
        int slotS = Math.min(20, rowH - 4);
        int iy = (slotS - 16) / 2;
        int railX = ex - 4;
        int railTop = top + 6;
        int railBot = top + 6 + (labels.length - 1) * rowH + slotS;
        g.fill(railX, railTop, railX + 1, railBot, RpTheme.alphaBlend(RpTheme.TEXT_DIM, 140));
        ItemStack hovered = ItemStack.EMPTY;
        for (int i = 0; i < labels.length; i++) {
            int ry = top + 6 + i * rowH;
            ItemStack stack = stacks[i];
            boolean loaded = stack != null && !stack.isEmpty();
            boolean weapon = i == labels.length - 1;
            int accent;
            int glow;
            if (!loaded) {
                accent = 0xFFB0B0B5;
                glow = 0;
            } else if (weapon) {
                accent = RpTheme.RED;
                glow = RpTheme.alphaBlend(RpTheme.RED, 40);
            } else {
                accent = RpTheme.BLUE;
                glow = RpTheme.alphaBlend(RpTheme.BLUE, 36);
            }
            // 槽位卡片
            RpRoundRect.outlined(g, ex, ry, ex + slotS, ry + slotS, RpTheme.RADIUS_SMALL, accent, RpTheme.CARD_BG);
            g.fill(ex + 1, ry + 1, ex + slotS - 1, ry + 2, accent);
            if (loaded) {
                g.fill(ex + 1, ry + 3, ex + slotS - 1, ry + slotS - 1, glow);
                g.renderItem(stack, ex + iy, ry + iy);
                if (mx >= ex && mx <= ex + slotS && my >= ry && my <= ry + slotS) {
                    hovered = stack;
                }
            } else {
                g.drawString(font, "—", ex + slotS / 2 - 2, ry + slotS / 2 - 4, RpTheme.TEXT_DIM);
            }
            int labelColor = loaded ? (weapon ? RpTheme.RED : RpTheme.TEXT_PRIMARY) : RpTheme.TEXT_DIM;
            g.drawString(font, labels[i], ex + slotS + 6, ry + slotS / 2 - 4, labelColor, true);
        }
        // 悬停物品显示词条
        if (!hovered.isEmpty()) {
            g.renderTooltip(font, hovered, mx, my);
        }
    }

    private static ItemStack armorStack(JsonObject loadout, int slot) {
        if (loadout == null || !loadout.has("armor") || !loadout.get("armor").isJsonArray()) {
            return ItemStack.EMPTY;
        }
        try {
            List<ProfessionJson.SlotItem> list =
                    ProfessionJson.listFromJson(loadout.getAsJsonArray("armor"), "armor", new ArrayList<>());
            for (ProfessionJson.SlotItem s : list) {
                if (s.slot() == slot) {
                    return ItemStackCodec.toStack(s);
                }
            }
        } catch (Exception ignored) {
            // 预览装备失败不致命
        }
        return ItemStack.EMPTY;
    }

    private static ItemStack weaponStack(JsonObject loadout) {
        if (loadout == null) {
            return ItemStack.EMPTY;
        }
        try {
            if (loadout.has("inventory") && loadout.get("inventory").isJsonArray()) {
                List<ProfessionJson.SlotItem> inv = ProfessionJson.listFromJson(
                        loadout.getAsJsonArray("inventory"), "inventory", new ArrayList<>());
                for (ProfessionJson.SlotItem s : inv) {
                    ItemStack st = ItemStackCodec.toStack(s);
                    if (isWeapon(st)) {
                        return st;
                    }
                }
                for (ProfessionJson.SlotItem s : inv) {
                    ItemStack st = ItemStackCodec.toStack(s);
                    if (!st.isEmpty()) {
                        return st;
                    }
                }
            }
        } catch (Exception ignored) {
            // 预览装备失败不致命
        }
        return ItemStack.EMPTY;
    }

    private static boolean isWeapon(ItemStack stack) {
        if (stack == null || stack.isEmpty()) {
            return false;
        }
        net.minecraft.world.item.Item it = stack.getItem();
        if (it instanceof net.minecraft.world.item.SwordItem
                || it instanceof net.minecraft.world.item.AxeItem
                || it instanceof net.minecraft.world.item.TridentItem
                || it instanceof net.minecraft.world.item.BowItem
                || it instanceof net.minecraft.world.item.CrossbowItem
                || it instanceof net.minecraft.world.item.ShieldItem) {
            return true;
        }
        net.minecraft.resources.ResourceLocation key = net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(it);
        String p2 = key == null ? "" : key.getPath().toLowerCase(Locale.ROOT);
        return p2.contains("gun")
                || p2.contains("rifle")
                || p2.contains("pistol")
                || p2.contains("weapon")
                || p2.contains("sword")
                || p2.contains("carbine");
    }

    private void renderNotice(GuiGraphics g) {
        if (!notice.isBlank() && System.currentTimeMillis() < noticeUntil) {
            g.drawCenteredString(font, "[ 系统 ] " + notice, (px1 + px2) / 2, py2 - 20, RpTheme.BLUE);
        }
    }

    // ---------- 重新部署确认弹窗（暂时隐藏） ----------

    /** 确认弹窗两个按钮矩形（确认/取消），渲染与点击共用。 */
    private int[][] confirmButtonRects() {
        int cw = Math.min(420, px2 - px1 - 40);
        int ch = 130;
        int cx = px1 + (px2 - px1 - cw) / 2;
        int cy = py1 + (py2 - py1 - ch) / 2;
        int bw = (cw - 40) / 2;
        int by = cy + ch - 36;
        return new int[][] {
            {cx + 12, by, cx + 12 + bw, by + 22},
            {cx + cw - 12 - bw, by, cx + cw - 12, by + 22}
        };
    }

    private void renderKillConfirm(GuiGraphics g, int mx, int my) {
        int cw = Math.min(420, px2 - px1 - 40);
        int ch = 130;
        int cx = px1 + (px2 - px1 - cw) / 2;
        int cy = py1 + (py2 - py1 - ch) / 2;
        g.fill(0, 0, width, height, 0x99000000); // 半透明遮罩
        RpTheme.terminalPanel(g, cx, cy, cx + cw, cy + ch, RpTheme.RADIUS_LARGE);
        g.drawString(
                font,
                Component.translatable("ccnr_rp.gui.character.kill_confirm_title")
                        .getString(),
                cx + 14,
                cy + 12,
                RpTheme.BLUE,
                true);
        JsonObject p = findProfession(confirmDeployId);
        String name = p == null ? confirmDeployId : str(p, "name");
        String msg = Component.translatable("ccnr_rp.gui.character.kill_confirm_msg", name)
                .getString();
        int ly = cy + 40;
        for (String line : wrapText(msg, cw - 28)) {
            g.drawString(font, line, cx + 14, ly, RpTheme.TEXT_PRIMARY, true);
            ly += 13;
        }
        int[][] rects = confirmButtonRects();
        boolean hYes = mx >= rects[0][0] && mx <= rects[0][2] && my >= rects[0][1] && my <= rects[0][3];
        boolean hNo = mx >= rects[1][0] && mx <= rects[1][2] && my >= rects[1][1] && my <= rects[1][3];
        RpRoundRect.fill(
                g,
                rects[0][0],
                rects[0][1],
                rects[0][2],
                rects[0][3],
                RpTheme.RADIUS_MEDIUM,
                hYes ? RpTheme.BLUE_HOVER : RpTheme.BLUE);
        g.drawCenteredString(
                font,
                Component.translatable("ccnr_rp.gui.character.kill_confirm_yes").getString(),
                (rects[0][0] + rects[0][2]) / 2,
                rects[0][1] + 6,
                RpTheme.TEXT_WHITE);
        RpRoundRect.fill(
                g,
                rects[1][0],
                rects[1][1],
                rects[1][2],
                rects[1][3],
                RpTheme.RADIUS_MEDIUM,
                hNo ? RpTheme.CARD_BG_ALT : RpTheme.CARD_BG);
        RpRoundRect.outlined(
                g,
                rects[1][0],
                rects[1][1],
                rects[1][2],
                rects[1][3],
                RpTheme.RADIUS_MEDIUM,
                RpTheme.BORDER,
                RpTheme.CARD_BG);
        g.drawCenteredString(
                font,
                Component.translatable("ccnr_rp.gui.character.kill_confirm_no").getString(),
                (rects[1][0] + rects[1][2]) / 2,
                rects[1][1] + 6,
                RpTheme.TEXT_PRIMARY);
    }

    /** 按像素宽度折行（中文/长职位名）。 */
    private java.util.List<String> wrapText(String text, int maxW) {
        java.util.List<String> out = new java.util.ArrayList<>();
        if (text == null || text.isBlank()) {
            out.add("");
            return out;
        }
        StringBuilder cur = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '\n' || font.width(cur.toString() + c) > maxW) {
                out.add(cur.toString());
                cur.setLength(0);
                if (c == '\n') {
                    continue;
                }
            }
            cur.append(c);
        }
        if (cur.length() > 0) {
            out.add(cur.toString());
        }
        return out;
    }

    private static String str(JsonObject o, String key) {
        return o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : "";
    }

    @Override
    public void onClose() {
        open = null;
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
