/*
 * Copyright (c) 2026 CCNR
 * SPDX-License-Identifier: MIT
 */
package com.ccnrcom.rp.faction;

import com.ccnrcom.rp.CCNRRPMod;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * 同阵营玩家伤害拦截（服务端权威）：
 * <ul>
 *   <li>监听 {@link LivingHurtEvent}，攻击者与被击玩家属于<b>同一阵营</b>（factionId 相同）时取消伤害。</li>
 *   <li>阵营取自 {@link CCNRRPMod#users}（UserService 用户档案），<b>与 factions.json 关系配置无关</b>——
 *       即使阵营关系被配置为敌对，同阵营玩家之间仍无法造成伤害。</li>
 *   <li>攻击者解析链（覆盖间接伤害）：
 *       直接实体为玩家 → 实体来源为玩家 → 发射物（箭/三叉戟/雪球等）owner → TNT owner。</li>
 *   <li>苦力怕爆炸等原版无法追溯引燃者的来源不在覆盖范围（原版限制，无 owner 信息）。</li>
 * </ul>
 */
public final class FriendlyFireGuard {

    private FriendlyFireGuard() {}

    @SubscribeEvent
    public static void onLivingHurt(LivingHurtEvent event) {
        if (event.isCanceled() || event.getEntity().level().isClientSide) {
            return; // 服务端权威：客户端事件不处理
        }
        if (CCNRRPMod.users == null) {
            return; // 用户服务尚未就绪
        }
        if (!(event.getEntity() instanceof ServerPlayer victim)) {
            return; // 只拦截玩家受到伤害
        }
        ServerPlayer attacker = resolveAttacker(event.getSource());
        if (attacker == null || attacker == victim) {
            return;
        }
        String victimFaction = CCNRRPMod.users.factionId(victim.getUUID().toString());
        String attackerFaction = CCNRRPMod.users.factionId(attacker.getUUID().toString());
        if (victimFaction != null && !victimFaction.isBlank() && victimFaction.equals(attackerFaction)) {
            event.setCanceled(true); // 同阵营免疫伤害
        }
    }

    /** 从伤害来源解析出攻击玩家；无法解析（环境伤害/无主来源）返回 null。 */
    private static ServerPlayer resolveAttacker(DamageSource source) {
        Entity direct = source.getDirectEntity();
        Entity indirect = source.getEntity();
        // 直接/间接实体本身是玩家（近战、直接攻击）
        if (direct instanceof ServerPlayer p) {
            return p;
        }
        if (indirect instanceof ServerPlayer p) {
            return p;
        }
        // 发射物（箭/三叉戟/雪球/火球等）：追溯发射者
        if (direct instanceof Projectile proj) {
            return proj.getOwner() instanceof ServerPlayer p ? p : null;
        }
        // TNT：追溯点燃者
        if (direct instanceof PrimedTnt tnt) {
            return tnt.getOwner() instanceof ServerPlayer p ? p : null;
        }
        return null;
    }
}
