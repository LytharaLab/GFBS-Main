/*
 * Copyright (c) 2026 CCNR
 * SPDX-License-Identifier: MIT
 */
package com.ccnrcom.rp.gui;

import java.util.List;
import net.minecraft.server.level.ServerPlayer;

/**
 * AUI 界面打开入口（替代原 LDLib RpUIFactory）。
 *
 * <p>同一份 HTML 四种宿主通用。本类负责把模组各界面映射到 AUI 逻辑路径：
 * <ul>
 *   <li>纯展示全屏界面：服务端 {@link #open(ServerPlayer, String)}（无容器，UI-only Screen）；</li>
 *   <li>客户端侧由 {@link com.sighs.apricityui.ApricityUI#screen(String)} 直接打开。</li>
 * </ul>
 *
 * <p>页面资源打包在 mod jar 的 <code>assets/apricityui/apricity/ccnr_rp/</code> 下
 * （dev 模式亦从 <code>src/main/resources/assets/apricityui/apricity</code> 读取），
 * 逻辑路径免 <code>assets/...</code> 前缀。AUI 未安装时降级为纯客户端提示。
 */
public final class AuiScreens {

    /** 页面逻辑路径前缀（对应 jar 内 assets/apricityui/apricity/ccnr_rp/）。 */
    public static final String ROOT = "ccnr_rp/";

    /** 角色选择/角色终端。 */
    public static final String CHARACTER = ROOT + "screens/character.html";
    /** 设置/管理面板。 */
    public static final String SETTINGS = ROOT + "screens/settings.html";
    /** 阵营信息面板。 */
    public static final String FACTION = ROOT + "screens/faction.html";
    /** 玩家状态面板。 */
    public static final String STATUS = ROOT + "screens/status.html";

    private AuiScreens() {}

    /** 服务端打开纯展示 Screen（无容器绑定）；AUI 缺失时返回 false。 */
    public static boolean open(ServerPlayer player, String templatePath) {
        if (player == null || templatePath == null || templatePath.isBlank()) return false;
        try {
            com.sighs.apricityui.network.handler.ApricityScreenNetworkHandler.openScreen(
                    player, templatePath, List.of());
            return true;
        } catch (Throwable t) {
            org.apache.logging.log4j.LogManager.getLogger().debug("[CCNR-RP] AUI 打开失败（可能未安装）: {}", t.toString());
            return false;
        }
    }

    /**
     * 客户端直接打开 AUI Screen（纯客户端，不走服务端容器）。
     *
     * @return true=已打开；false=AUI 缺失或页面无效（调用方自行降级）
     */
    public static boolean clientOpen(String templatePath) {
        if (templatePath == null || templatePath.isBlank()) return false;
        try {
            net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
            if (mc == null || mc.player == null) {
                return false;
            }
            com.sighs.apricityui.ApricityUI.screen(templatePath);
            return true;
        } catch (Throwable t) {
            org.apache.logging.log4j.LogManager.getLogger().debug("[CCNR-RP] AUI 客户端打开失败（可能未安装）: {}", t.toString());
            return false;
        }
    }
}
